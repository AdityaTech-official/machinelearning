"""Resume parsing: text extraction (PDF/DOCX/TXT) plus structured parsing.

Two paths are provided:
* :func:`parse_resume` uses the LLM when configured, validated against
  :class:`~database.models.ResumeData`.
* :func:`parse_resume_deterministic` is a fully offline rule engine using the
  skill lexicon - it is the fallback and is also what the unit tests exercise.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from config.settings import MAX_RESUME_CHARS
from config.skills_lexicon import DEGREE_KEYWORDS, SKILL_ALIASES, SURFACE_TO_CANONICAL
from database.models import (
    Certification,
    Education,
    Experience,
    Project,
    ResumeData,
)
from services.llm_service import LLMService, load_prompt, render_prompt
from utils.validators import (
    clean_text,
    extract_emails,
    extract_phones,
    truncate,
)

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Text extraction
# --------------------------------------------------------------------------- #
def extract_text_from_file(path: Path) -> str:
    """Extract raw text from a .pdf, .docx or .txt file.

    Raises :class:`ValueError` with a user-friendly message on failure.
    """
    path = Path(path)
    if not path.exists():
        raise ValueError(f"File not found: {path.name}")
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        return _extract_pdf(path)
    if suffix == ".docx":
        return _extract_docx(path)
    if suffix == ".txt":
        return clean_text(path.read_text(encoding="utf-8", errors="ignore"))
    raise ValueError(f"Unsupported file type: {suffix}")


def _extract_pdf(path: Path) -> str:
    """Extract text from a PDF using pypdf."""
    try:
        from pypdf import PdfReader
    except ImportError as exc:  # pragma: no cover
        raise ValueError("pypdf is not installed. Run: pip install pypdf") from exc

    try:
        reader = PdfReader(str(path))
        if getattr(reader, "is_encrypted", False):
            try:
                reader.decrypt("")
            except Exception as exc:  # noqa: BLE001
                raise ValueError("This PDF is password-protected.") from exc
        pages = [page.extract_text() or "" for page in reader.pages]
    except ValueError:
        raise
    except Exception as exc:  # noqa: BLE001 - malformed PDFs raise many types
        raise ValueError(f"Could not read the PDF file ({type(exc).__name__}).") from exc

    text = clean_text("\n".join(pages))
    if not text:
        raise ValueError(
            "No extractable text found. The PDF may be a scanned image; "
            "please upload a text-based PDF or a DOCX file."
        )
    return text


def _extract_docx(path: Path) -> str:
    """Extract text from a DOCX using python-docx, including tables."""
    try:
        import docx
    except ImportError as exc:  # pragma: no cover
        raise ValueError("python-docx is not installed. Run: pip install python-docx") from exc

    try:
        document = docx.Document(str(path))
    except Exception as exc:  # noqa: BLE001
        raise ValueError(
            f"Could not read the DOCX file ({type(exc).__name__}). "
            "The file may be corrupt."
        ) from exc

    parts: list[str] = [p.text for p in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
            if cells:
                parts.append(" | ".join(cells))
    text = clean_text("\n".join(parts))
    if not text:
        raise ValueError("The DOCX file contains no readable text.")
    return text


# --------------------------------------------------------------------------- #
# Deterministic parsing
# --------------------------------------------------------------------------- #
_SECTION_HEADINGS = {
    "education": ("education", "academic", "qualification"),
    "skills": ("skills", "technical skills", "technologies", "tech stack"),
    "experience": ("experience", "employment", "work history", "internship"),
    "projects": ("projects", "project work", "key projects"),
    "certifications": ("certification", "certifications", "licenses", "courses"),
}


def _split_sections(text: str) -> dict[str, list[str]]:
    """Split resume text into a {section: [lines]} mapping using headings."""
    sections: dict[str, list[str]] = {key: [] for key in _SECTION_HEADINGS}
    sections["_header"] = []
    current = "_header"
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        lowered = line.lower().rstrip(":").strip()
        matched = None
        if len(lowered.split()) <= 4:
            for key, keywords in _SECTION_HEADINGS.items():
                if any(lowered == kw or lowered.startswith(kw) for kw in keywords):
                    matched = key
                    break
        if matched:
            current = matched
            continue
        sections[current].append(line)
    return sections


def _detect_skills(text: str) -> list[str]:
    """Detect canonical skills present in text using the lexicon."""
    lowered = f" {text.lower()} "
    found: list[str] = []
    for surface, canonical in SURFACE_TO_CANONICAL.items():
        token = surface.strip()
        if not token:
            continue
        # Word-boundary-ish check that also handles punctuation like c++/node.js
        if f" {token} " in lowered or f" {token}," in lowered or f" {token}." in lowered:
            if canonical not in found:
                found.append(canonical)
    # Preserve the lexicon's canonical ordering for stability.
    ordered = [c for c in SKILL_ALIASES if c in found]
    return ordered


def _guess_name(header_lines: list[str]) -> str:
    """Heuristically pick the candidate name from the top of the resume."""
    for line in header_lines[:6]:
        if any(ch.isdigit() for ch in line) or "@" in line:
            continue
        words = line.split()
        if 1 < len(words) <= 5 and len(line) <= 60:
            return line
    return ""


def parse_resume_deterministic(text: str) -> ResumeData:
    """Rule-based resume parser used as the offline fallback."""
    text = clean_text(text)
    sections = _split_sections(text)
    emails = extract_emails(text)
    phones = extract_phones(text)

    education: list[Education] = []
    for line in sections["education"]:
        low = line.lower()
        if any(kw in low for kw in DEGREE_KEYWORDS):
            year = None
            import re

            year_match = re.search(r"(19|20)\d{2}", line)
            if year_match:
                year = year_match.group(0)
            education.append(
                Education(degree=line, institution="", year=year, details="")
            )

    experience: list[Experience] = []
    for line in sections["experience"]:
        experience.append(
            Experience(title=line, company="", duration="", description=[line])
        )

    projects: list[Project] = []
    for line in sections["projects"]:
        projects.append(Project(name=line[:80], description=line, technologies=[]))

    certifications: list[Certification] = []
    for line in sections["certifications"]:
        certifications.append(Certification(name=line[:100], issuer="", year=None))

    skills = _detect_skills(text)

    return ResumeData(
        name=_guess_name(sections["_header"]),
        email=emails[0] if emails else "",
        phone=phones[0] if phones else "",
        summary=" ".join(sections["_header"][1:3])[:300],
        education=education,
        skills=skills,
        experience=experience,
        projects=projects,
        certifications=certifications,
        raw_text=truncate(text, MAX_RESUME_CHARS),
    )


def parse_resume(text: str, llm: Optional[LLMService] = None) -> ResumeData:
    """Parse resume text into structured data, using the LLM when available."""
    text = clean_text(text)
    if not text:
        return ResumeData()

    llm = llm or LLMService()
    truncated = truncate(text, MAX_RESUME_CHARS)
    template = load_prompt("resume_prompt.txt")
    prompt = render_prompt(template, resume_text=truncated)

    result = llm.complete_json(
        prompt,
        ResumeData,
        fallback=lambda: parse_resume_deterministic(text),
        system="You output strict JSON only.",
    )
    # Always retain the raw text locally so the UI can show/re-edit it.
    result.raw_text = truncate(text, MAX_RESUME_CHARS)
    return result
