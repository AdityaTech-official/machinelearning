"""Job-description parsing: structured extraction of requirements.

The deterministic engine splits a pasted JD into lines, classifies each line as
required vs. preferred using marker phrases, and detects skills via the lexicon.
The LLM path (when configured) is validated against
:class:`~database.models.JobRequirements`.
"""

from __future__ import annotations

import logging
import re
from typing import Optional

from config.skills_lexicon import (
    DEGREE_KEYWORDS,
    PREFERRED_MARKERS,
    REQUIRED_MARKERS,
    SKILL_ALIASES,
    SURFACE_TO_CANONICAL,
)
from database.models import JobRequirements
from services.llm_service import LLMService
from utils.validators import clean_text, extract_years_of_experience

logger = logging.getLogger(__name__)

_RESPONSIBILITY_HEADS = ("responsibilities", "what you will do", "role", "duties")
_QUALIFICATION_HEADS = ("qualifications", "requirements", "must have", "skills")


def _detect_skills_in(text: str) -> list[str]:
    """Return canonical skills found in a block of text (stable order)."""
    lowered = f" {text.lower()} "
    found: set[str] = set()
    for surface, canonical in SURFACE_TO_CANONICAL.items():
        token = surface.strip()
        if token and (f" {token} " in lowered or f" {token}," in lowered):
            found.add(canonical)
    return [c for c in SKILL_ALIASES if c in found]


def parse_job_deterministic(text: str) -> JobRequirements:
    """Rule-based job-description parser (offline fallback)."""
    text = clean_text(text)
    lines = [ln.strip(" \t-•*") for ln in text.splitlines() if ln.strip()]

    title = lines[0][:120] if lines else ""
    company = ""
    low_full = text.lower()

    required: list[str] = []
    preferred: list[str] = []
    responsibilities: list[str] = []
    qualifications: list[str] = []

    current_bucket = qualifications
    for line in lines:
        low = line.lower()
        if any(h in low for h in _RESPONSIBILITY_HEADS) and len(low.split()) <= 6:
            current_bucket = responsibilities
            continue
        if any(h in low for h in _QUALIFICATION_HEADS) and len(low.split()) <= 6:
            current_bucket = qualifications
            continue

        skills_here = _detect_skills_in(line)
        is_preferred = any(marker in low for marker in PREFERRED_MARKERS)
        is_required = any(marker in low for marker in REQUIRED_MARKERS)

        for skill in skills_here:
            if is_preferred and not is_required:
                if skill not in preferred:
                    preferred.append(skill)
            else:
                if skill not in required:
                    required.append(skill)

        if current_bucket is responsibilities:
            responsibilities.append(line)
        elif 2 <= len(line.split()) <= 40:
            qualifications.append(line)

    # If nothing was classified as required, treat all detected skills as required.
    if not required:
        required = _detect_skills_in(text)

    # A skill cannot be both required and preferred.
    preferred = [s for s in preferred if s not in required]

    years = extract_years_of_experience(text)
    experience_required = f"{years:g}+ years" if years else ""

    education_required = ""
    for line in lines:
        if any(kw in line.lower() for kw in DEGREE_KEYWORDS):
            education_required = line[:120]
            break

    return JobRequirements(
        title=title,
        company=company,
        required_skills=required[:25],
        preferred_skills=preferred[:15],
        responsibilities=responsibilities[:15],
        qualifications=qualifications[:20],
        experience_required=experience_required,
        education_required=education_required,
    )


def parse_job_description(
    text: str, llm: Optional[LLMService] = None
) -> JobRequirements:
    """Parse a pasted job description into structured requirements."""
    text = clean_text(text)
    if not text:
        return JobRequirements()

    llm = llm or LLMService()
    prompt = (
        "Extract structured hiring requirements from the job description below. "
        "Return strict JSON with keys: title, company, required_skills, "
        "preferred_skills, responsibilities, qualifications, experience_required, "
        "education_required. Do not invent anything that is not in the text.\n\n"
        f"JOB DESCRIPTION:\n{text[:8000]}"
    )
    return llm.complete_json(
        prompt,
        JobRequirements,
        fallback=lambda: parse_job_deterministic(text),
        system="You output strict JSON only.",
    )
