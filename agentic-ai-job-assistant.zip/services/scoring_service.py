"""Explainable, rule-based scoring for resume <-> job matching.

IMPORTANT DESIGN NOTE
---------------------
This module computes a *transparent similarity index* from observable overlap
(skills, experience, education, resume completeness). It is NOT a machine-learned
model and it does NOT predict hiring probability. Every component of the score
is exposed in the ``breakdown`` so a reviewer can audit it - which is exactly
what the specification requires.
"""

from __future__ import annotations

import logging
from typing import Optional

from config.settings import ScoringWeights, SCORING_WEIGHTS
from config.skills_lexicon import SKILL_ALIASES, UNVERIFIABLE_MARKERS
from database.models import (
    JobRequirements,
    MatchResult,
    ResumeData,
    SkillMatch,
)
from services.llm_service import LLMService, load_prompt, render_prompt
from utils.validators import extract_years_of_experience


logger = logging.getLogger(__name__)

# Related-skill map: a resume skill that *partially* evidences a required skill.
RELATED_SKILLS: dict[str, set[str]] = {
    "React": {"JavaScript", "HTML", "CSS", "Next.js", "Node.js"},
    "Next.js": {"React", "JavaScript"},
    "Node.js": {"JavaScript", "Express", "React"},
    "Django": {"Python", "Flask", "REST API"},
    "Flask": {"Python", "Django", "REST API"},
    "FastAPI": {"Python", "Flask", "REST API"},
    "Machine Learning": {"Python", "scikit-learn", "Pandas", "NumPy", "Statistics"},
    "Deep Learning": {"Machine Learning", "PyTorch", "TensorFlow", "Python"},
    "NLP": {"Machine Learning", "Python", "Deep Learning", "LLM"},
    "PyTorch": {"Deep Learning", "Machine Learning", "Python"},
    "TensorFlow": {"Deep Learning", "Machine Learning", "Python"},
    "AWS": {"Docker", "Linux", "CI/CD"},
    "Kubernetes": {"Docker", "AWS", "Linux"},
    "PostgreSQL": {"SQL", "MySQL"},
    "MySQL": {"SQL", "PostgreSQL"},
    "MongoDB": {"SQL"},
    "REST API": {"Flask", "FastAPI", "Django", "Node.js"},
    "LangChain": {"LLM", "Python", "RAG", "Prompt Engineering"},
    "RAG": {"LangChain", "LLM", "NLP"},
}


def _canonicalise(skill: str) -> str:
    """Map any surface form to its canonical skill name."""
    low = skill.strip().lower()
    for canonical in SKILL_ALIASES:
        if canonical.lower() == low:
            return canonical
    return skill.strip()


class ScoringService:
    """Computes explainable match results from resume and job structures."""

    def __init__(self, weights: ScoringWeights | None = None) -> None:
        self.weights = weights or SCORING_WEIGHTS

    # ------------------------------------------------------------------ #
    # Deterministic classification
    # ------------------------------------------------------------------ #
    def _classify_skill(
        self,
        required_skill: str,
        resume: ResumeData,
    ) -> SkillMatch:
        """Classify one required/preferred skill against resume evidence."""
        canonical = _canonicalise(required_skill)
        resume_skills = {_canonicalise(s) for s in resume.skills}
        raw_lower = (resume.raw_text or "").lower()

        if canonical in resume_skills:
            return SkillMatch(
                skill=canonical,
                evidence=f"Listed in skills: {canonical}",
                reason="Exact skill match found in the resume's skills section.",
            )

        # Weak evidence: mentioned in the raw text but not in the skills list.
        if canonical.lower() in raw_lower:
            return SkillMatch(
                skill=canonical,
                evidence="Mentioned in the resume body but not in the skills list.",
                reason="Mentioned only in passing; evidence is weak. Move it into "
                "your skills section if you are genuinely proficient.",
            )

        # Partial: a related skill is present, or the reverse direction holds.
        related = RELATED_SKILLS.get(canonical, set())
        overlap = related & resume_skills
        if overlap:
            return SkillMatch(
                skill=canonical,
                evidence=f"Related skill present: {', '.join(sorted(overlap))}",
                reason="Related technology present, but the exact skill is not "
                "demonstrated. Add a project using it to strengthen this.",
            )

        return SkillMatch(
            skill=canonical,
            evidence="",
            reason="No evidence of this skill was found in the resume.",
        )

    def _score_experience(self, resume: ResumeData, job: JobRequirements) -> float:
        """Compare years of experience in the resume against the JD requirement."""
        if not job.experience_required:
            return 1.0  # nothing to verify -> full credit, neutral
        required_years = extract_years_of_experience(job.experience_required)
        if required_years == 0:
            # Qualitative requirement (e.g. "proven experience"): reward presence.
            return 1.0 if resume.experience else 0.4
        resume_years = extract_years_of_experience(resume.raw_text)
        if required_years == 0:
            return 1.0
        ratio = min(resume_years / required_years, 1.0)
        return round(max(ratio, 0.0), 3)

    def _score_education(self, resume: ResumeData, job: JobRequirements) -> float:
        """1.0 if the JD has no education requirement or the resume shows education."""
        if not job.education_required:
            return 1.0
        return 1.0 if resume.education else 0.0

    def _score_completeness(self, resume: ResumeData) -> float:
        """Fraction of key resume sections that are populated."""
        fields = [
            bool(resume.skills),
            bool(resume.education),
            bool(resume.experience),
            bool(resume.projects),
            bool(resume.summary or resume.name),
        ]
        return round(sum(fields) / len(fields), 3)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def match(self, resume: ResumeData, job: JobRequirements) -> MatchResult:
        """Produce an explainable :class:`MatchResult` for a resume and job."""
        required = [_canonicalise(s) for s in job.required_skills]
        preferred = [_canonicalise(s) for s in job.preferred_skills]

        matched: list[SkillMatch] = []
        partial: list[SkillMatch] = []
        missing: list[SkillMatch] = []
        unsupported: list[SkillMatch] = []

        # Unverifiable requirements stay separate from the score entirely.
        job_blob = " ".join(
            job.required_skills + job.preferred_skills + job.qualifications
        ).lower()
        for marker in UNVERIFIABLE_MARKERS:
            if marker in job_blob:
                unsupported.append(
                    SkillMatch(
                        skill=marker.title(),
                        reason="This requirement cannot be verified from a resume; "
                        "raise it directly with the employer.",
                    )
                )

        def classify_all(skills: list[str]) -> None:
            for skill in skills:
                if any(m.skill == skill for m in matched + partial + missing):
                    continue
                judgement = self._classify_skill(skill, resume)
                if judgement.evidence and "Exact skill match" in judgement.reason:
                    matched.append(judgement)
                elif judgement.evidence:
                    partial.append(judgement)
                else:
                    missing.append(judgement)

        classify_all(required)
        classify_all(preferred)

        # --- Component scores (0..1) ---------------------------------- #
        def ratio(items: list[str], bucket: list[SkillMatch]) -> float:
            if not items:
                return 1.0
            total = len(items)
            full = sum(1 for i in items if any(m.skill == i for m in matched))
            half = sum(1 for i in items if any(m.skill == i for m in partial))
            return min((full + 0.5 * half) / total, 1.0)

        req_ratio = ratio(required, matched)
        pref_ratio = ratio(preferred, matched)
        exp_ratio = self._score_experience(resume, job)
        edu_ratio = self._score_education(resume, job)
        comp_ratio = self._score_completeness(resume)

        w = self.weights
        overall = (
            req_ratio * w.required_skills
            + pref_ratio * w.preferred_skills
            + exp_ratio * w.experience
            + edu_ratio * w.education
            + comp_ratio * w.resume_completeness
        ) * 100

        breakdown = {
            "Required skills": round(req_ratio * 100, 1),
            "Preferred skills": round(pref_ratio * 100, 1),
            "Experience": round(exp_ratio * 100, 1),
            "Education": round(edu_ratio * 100, 1),
            "Resume completeness": round(comp_ratio * 100, 1),
        }

        explanation = (
            f"{len(matched)} matched, {len(partial)} partially matched and "
            f"{len(missing)} missing across "
            f"{len(required)} required and {len(preferred)} preferred skills. "
            f"Strongest area: {max(breakdown, key=breakdown.get)}."
        )

        return MatchResult(
            overall_score=round(overall, 1),
            matched=matched,
            partial=partial,
            missing=missing,
            unsupported=unsupported,
            breakdown=breakdown,
            explanation=explanation,
        )

    # ------------------------------------------------------------------ #
    # Optional LLM-assisted matching (validated, falls back deterministically)
    # ------------------------------------------------------------------ #
    def match_with_llm(
        self,
        resume: ResumeData,
        job: JobRequirements,
        llm: Optional[LLMService] = None,
    ) -> MatchResult:
        """Deterministic score, optionally enriched by LLM classification.

        The deterministic score is ALWAYS the source of truth for the number;
        the LLM may only refine the matched/partial/missing buckets, and its
        output is validated before use.
        """
        base = self.match(resume, job)
        llm = llm or LLMService()
        if not llm.available:
            return base

        template = load_prompt("match_prompt.txt")
        prompt = render_prompt(
            template,
            required_skills=", ".join(job.required_skills) or "none",
            preferred_skills=", ".join(job.preferred_skills) or "none",
            experience_required=job.experience_required or "not specified",
            education_required=job.education_required or "not specified",
            resume_evidence=(resume.raw_text or "")[:4000],
        )

        from pydantic import BaseModel, Field

        class _Buckets(BaseModel):
            matched: list[SkillMatch] = Field(default_factory=list)
            partial: list[SkillMatch] = Field(default_factory=list)
            missing: list[SkillMatch] = Field(default_factory=list)
            unsupported: list[SkillMatch] = Field(default_factory=list)

        def fallback() -> _Buckets:
            return _Buckets(
                matched=base.matched,
                partial=base.partial,
                missing=base.missing,
                unsupported=base.unsupported,
            )

        buckets = llm.complete_json(prompt, _Buckets, fallback=fallback)
        base.matched = buckets.matched or base.matched
        base.partial = buckets.partial or base.partial
        base.missing = buckets.missing or base.missing
        if buckets.unsupported:
            base.unsupported = buckets.unsupported
        return base
