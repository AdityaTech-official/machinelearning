"""Provider-agnostic LLM adapter with validation, retries and a safe fallback.

This is the ONLY module in the project that touches an LLM provider. Every
caller receives a *validated Pydantic model* or a deterministic fallback - never
raw, unvalidated text.
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Callable, Optional, Type, TypeVar

from pydantic import BaseModel, ValidationError

from config.settings import (
    LLM_MAX_RETRIES,
    LLM_MODEL,
    LLM_PROVIDER,
    LLM_TEMPERATURE,
    LLM_TIMEOUT,
    OPENAI_API_KEY,
    OPENAI_BASE_URL,
    PROMPTS_DIR,
    llm_configured,
)

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

_JSON_BLOCK_RE = re.compile(r"\{.*\}", re.DOTALL)


class LLMUnavailableError(RuntimeError):
    """Raised when an LLM call is attempted but no provider is configured."""


def load_prompt(name: str) -> str:
    """Read a prompt template from ``prompts/`` and return its raw text."""
    path = PROMPTS_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"Prompt template not found: {path}")
    return path.read_text(encoding="utf-8")


def render_prompt(template: str, **values: object) -> str:
    """Safely substitute ``{key}`` placeholders without exploding on braces in data.

    We use a manual ``replace`` loop rather than ``str.format`` because resume
    text frequently contains literal curly braces.
    """
    out = template
    for key, value in values.items():
        out = out.replace("{" + key + "}", str(value))
    return out


class LLMService:
    """Adapter that talks to a chat model through LangChain when configured.

    The service degrades gracefully: when no API key is present
    :meth:`available` returns False and callers use their deterministic engine.
    """

    def __init__(
        self,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        timeout: Optional[int] = None,
        max_retries: Optional[int] = None,
        client: object | None = None,
    ) -> None:
        self.provider = (provider or LLM_PROVIDER).lower()
        self.model = model or LLM_MODEL
        self.temperature = LLM_TEMPERATURE if temperature is None else temperature
        self.timeout = timeout or LLM_TIMEOUT
        self.max_retries = max_retries or LLM_MAX_RETRIES
        self._client = client  # injectable for tests

    # ------------------------------------------------------------------ #
    # Availability
    # ------------------------------------------------------------------ #
    @property
    def available(self) -> bool:
        """True when a usable client or provider credential exists."""
        if self._client is not None:
            return True
        return llm_configured() if self.provider == LLM_PROVIDER else bool(
            OPENAI_API_KEY and self.provider == "openai"
        )

    def _get_client(self) -> object:
        """Lazily construct the LangChain chat client."""
        if self._client is not None:
            return self._client
        if self.provider != "openai":
            raise LLMUnavailableError(
                f"Provider '{self.provider}' is not supported by this adapter."
            )
        if not OPENAI_API_KEY:
            raise LLMUnavailableError(
                "No OPENAI_API_KEY configured. Set it in .env to enable AI features."
            )
        # Imported lazily so the app starts even if langchain is not installed.
        from langchain_openai import ChatOpenAI

        kwargs: dict[str, object] = {
            "model": self.model,
            "temperature": self.temperature,
            "timeout": self.timeout,
            "max_retries": 0,  # we implement our own retry/backoff
            "api_key": OPENAI_API_KEY,
        }
        if OPENAI_BASE_URL:
            kwargs["base_url"] = OPENAI_BASE_URL
        self._client = ChatOpenAI(**kwargs)
        return self._client

    # ------------------------------------------------------------------ #
    # Raw completion with retry/backoff
    # ------------------------------------------------------------------ #
    def complete(self, prompt: str, system: str | None = None) -> str:
        """Send a prompt and return the model's text response.

        Retries transient failures with exponential backoff. The prompt content
        is never logged - only the prompt length and error types.
        """
        if not self.available:
            raise LLMUnavailableError("LLM is not configured.")
        client = self._get_client()

        from langchain_core.messages import HumanMessage, SystemMessage

        messages = []
        if system:
            messages.append(SystemMessage(content=system))
        messages.append(HumanMessage(content=prompt))

        last_error: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                logger.debug(
                    "LLM call attempt %d/%d (prompt chars=%d)",
                    attempt, self.max_retries, len(prompt),
                )
                response = client.invoke(messages)
                content = getattr(response, "content", response)
                if isinstance(content, list):  # some providers return content blocks
                    content = " ".join(
                        part.get("text", "") if isinstance(part, dict) else str(part)
                        for part in content
                    )
                return str(content).strip()
            except Exception as exc:  # noqa: BLE001 - provider errors vary widely
                last_error = exc
                logger.warning("LLM call failed (attempt %d): %s", attempt, type(exc).__name__)
                if attempt < self.max_retries:
                    time.sleep(min(2 ** attempt * 0.5, 4.0))
        raise LLMUnavailableError(f"LLM call failed after retries: {last_error}")

    # ------------------------------------------------------------------ #
    # Structured output with validation + fallback
    # ------------------------------------------------------------------ #
    def complete_json(
        self,
        prompt: str,
        schema: Type[T],
        fallback: Optional[Callable[[], T]] = None,
        system: str | None = None,
    ) -> T:
        """Return a validated Pydantic model, falling back deterministically.

        The model output is parsed and validated. If parsing or validation fails
        on every attempt, ``fallback()`` is used so the app keeps working.
        """
        if not self.available:
            if fallback is not None:
                logger.info("LLM unavailable - using deterministic fallback.")
                return fallback()
            raise LLMUnavailableError("LLM is not configured and no fallback was given.")

        try:
            raw = self.complete(prompt, system=system)
            payload = self._extract_json(raw)
            return schema.model_validate(payload)
        except (ValidationError, ValueError, TypeError) as exc:
            logger.warning("Structured output invalid: %s", exc)
        except LLMUnavailableError as exc:
            logger.warning("LLM call error: %s", exc)

        if fallback is not None:
            logger.info("Falling back to deterministic engine.")
            return fallback()
        raise LLMUnavailableError("LLM returned invalid structured output.")

    @staticmethod
    def _extract_json(text: str) -> dict:
        """Extract the first JSON object from a model response."""
        if not text:
            raise ValueError("Empty model response.")
        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", cleaned)
            cleaned = re.sub(r"\n?```$", "", cleaned).strip()
        match = _JSON_BLOCK_RE.search(cleaned)
        if not match:
            raise ValueError("No JSON object found in model response.")
        return json.loads(match.group(0))
