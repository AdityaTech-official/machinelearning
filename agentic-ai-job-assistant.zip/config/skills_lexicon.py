"""A curated skill lexicon used by the deterministic (no-LLM) fallback engines.

The lexicon powers two things:
1. Skill detection in free text (resume / job description) without an LLM.
2. Canonicalisation, so "reactjs", "react.js" and "React" all map to one skill.

The LLM path does not depend on this list, but when no API key is configured
this is what keeps every feature of the app fully functional and testable.
"""

from __future__ import annotations

# Canonical skill -> list of surface forms (lower-case) that map to it.
SKILL_ALIASES: dict[str, list[str]] = {
    # Programming languages
    "Python": ["python"],
    "Java": ["java"],
    "JavaScript": ["javascript", "js"],
    "TypeScript": ["typescript", "ts"],
    "C++": ["c++", "cpp"],
    "C": [" c ", "c language"],
    "C#": ["c#", "csharp"],
    "Go": ["golang", "go language"],
    "Rust": ["rust"],
    "SQL": ["sql"],
    "R": [" r ", "r language"],
    # Web / frontend
    "HTML": ["html"],
    "CSS": ["css"],
    "React": ["react", "reactjs", "react.js"],
    "Next.js": ["next.js", "nextjs"],
    "Angular": ["angular"],
    "Vue.js": ["vue", "vuejs", "vue.js"],
    "Node.js": ["node.js", "nodejs", "node"],
    "Tailwind CSS": ["tailwind"],
    "Streamlit": ["streamlit"],
    # Backend / frameworks
    "FastAPI": ["fastapi"],
    "Django": ["django"],
    "Flask": ["flask"],
    "Spring Boot": ["spring boot", "springboot", "spring"],
    "REST API": ["rest api", "restful", "rest apis"],
    "GraphQL": ["graphql"],
    "Microservices": ["microservices", "micro-service"],
    # Data / AI / ML
    "Machine Learning": ["machine learning", " ml "],
    "Deep Learning": ["deep learning", "neural network"],
    "NLP": ["nlp", "natural language processing"],
    "Computer Vision": ["computer vision", "opencv"],
    "Pandas": ["pandas"],
    "NumPy": ["numpy"],
    "scikit-learn": ["scikit-learn", "sklearn", "scikit learn"],
    "TensorFlow": ["tensorflow"],
    "PyTorch": ["pytorch", "torch"],
    "LangChain": ["langchain"],
    "LLM": ["llm", "large language model"],
    "RAG": ["rag", "retrieval augmented generation"],
    "Prompt Engineering": ["prompt engineering"],
    "Data Analysis": ["data analysis", "data analytics"],
    "Data Visualization": ["data visualization", "data visualisation"],
    "Statistics": ["statistics", "statistical"],
    "ETL": ["etl", "extract transform load"],
    # Databases
    "MySQL": ["mysql"],
    "PostgreSQL": ["postgresql", "postgres"],
    "MongoDB": ["mongodb", "mongo"],
    "SQLite": ["sqlite"],
    "Redis": ["redis"],
    "Oracle": ["oracle db", "oracle database"],
    # Cloud / DevOps
    "AWS": ["aws", "amazon web services"],
    "Azure": ["azure"],
    "Google Cloud": ["gcp", "google cloud"],
    "Docker": ["docker"],
    "Kubernetes": ["kubernetes", "k8s"],
    "CI/CD": ["ci/cd", "cicd", "continuous integration"],
    "Git": ["git"],
    "GitHub Actions": ["github actions"],
    "Linux": ["linux", "unix"],
    "Terraform": ["terraform"],
    # CS fundamentals
    "Data Structures": ["data structures"],
    "Algorithms": ["algorithms", "algorithm"],
    "OOP": ["oop", "object oriented", "object-oriented"],
    "System Design": ["system design"],
    "Operating Systems": ["operating systems"],
    "Computer Networks": ["computer networks", "networking"],
    "DBMS": ["dbms", "database management"],
    # Soft / process
    "Agile": ["agile", "scrum"],
    "Communication": ["communication"],
    "Problem Solving": ["problem solving", "problem-solving"],
    "Teamwork": ["teamwork", "collaboration"],
    "Testing": ["unit testing", "pytest", "test automation", "jest"],
}

# Reverse index: surface form -> canonical skill (built once at import time).
SURFACE_TO_CANONICAL: dict[str, str] = {}
for _canonical, _forms in SKILL_ALIASES.items():
    for _form in _forms:
        SURFACE_TO_CANONICAL[_form.strip()] = _canonical

# Canonical-name lookup used when the LLM returns e.g. "react.js".
CANONICAL_LOWER: dict[str, str] = {k.lower(): k for k in SKILL_ALIASES}

# Words that signal a *required* skill in a job description.
REQUIRED_MARKERS: tuple[str, ...] = (
    "required",
    "must have",
    "must-have",
    "requirements",
    "you have",
    "essential",
    "mandatory",
    "minimum",
)

# Words that signal a *preferred* / nice-to-have skill.
PREFERRED_MARKERS: tuple[str, ...] = (
    "preferred",
    "nice to have",
    "nice-to-have",
    "plus",
    "bonus",
    "good to have",
    "desirable",
    "advantage",
)

# Degree keywords for education matching.
DEGREE_KEYWORDS: tuple[str, ...] = (
    "b.tech",
    "btech",
    "b.e",
    "bachelor",
    "master",
    "m.tech",
    "mtech",
    "mba",
    "mca",
    "bca",
    "b.sc",
    "bsc",
    "m.sc",
    "msc",
    "phd",
    "diploma",
)

# Requirement phrases that cannot be verified from a resume.
UNVERIFIABLE_MARKERS: tuple[str, ...] = (
    "work authorization",
    "authorized to work",
    "visa",
    "security clearance",
    "background check",
    "portfolio",
    "github profile",
    "linkedin profile",
    "references",
)
