"""Central configuration for the Agentic AI Job Application Assistant.

All secrets are read from environment variables only. Nothing in this module
reads, prints, or logs a secret value: :func:`mask_secret` exists so that a
*redacted* fingerprint can be shown in the UI when useful for debugging.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
PROJECT_ROOT: Path = Path(__file__).resolve().parent.parent

# Load .env from the project root if it exists. Safe if the file is absent.
load_dotenv(PROJECT_ROOT / ".env")

DATA_DIR: Path = PROJECT_ROOT / "data"
PROMPTS_DIR: Path = PROJECT_ROOT / "prompts"
# Uploaded resumes are written here and are excluded from version control.
UPLOAD_DIR: Path = DATA_DIR / "uploads"

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------- #
# Database
# --------------------------------------------------------------------------- #
DB_PATH: Path = Path(os.getenv("DB_PATH", str(DATA_DIR / "applications.db")))

# --------------------------------------------------------------------------- #
# LLM provider configuration (provider-agnostic adapter in services/llm_service.py)
# --------------------------------------------------------------------------- #
LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "openai").strip().lower()
LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-4o-mini").strip()
LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0"))
LLM_TIMEOUT: int = int(os.getenv("LLM_TIMEOUT", "45"))
LLM_MAX_RETRIES: int = int(os.getenv("LLM_MAX_RETRIES", "3"))

# Credentials - never logged, never rendered.
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_BASE_URL: str | None = os.getenv("OPENAI_BASE_URL", "").strip() or None

# --------------------------------------------------------------------------- #
# Upload limits
# --------------------------------------------------------------------------- #
MAX_UPLOAD_MB: int = int(os.getenv("MAX_UPLOAD_MB", "5"))
MAX_UPLOAD_BYTES: int = MAX_UPLOAD_MB * 1024 * 1024
ALLOWED_EXTENSIONS: tuple[str, ...] = (".pdf", ".docx", ".txt")

# Maximum characters of resume text we ever send to an LLM (cost + privacy guard).
MAX_RESUME_CHARS: int = int(os.getenv("MAX_RESUME_CHARS", "12000"))

# --------------------------------------------------------------------------- #
# Application status workflow
# --------------------------------------------------------------------------- #
APPLICATION_STATUSES: tuple[str, ...] = (
    "Interested",
    "Preparing",
    "Applied",
    "Interview",
    "Offer",
    "Rejected",
)


@dataclass(frozen=True)
class ScoringWeights:
    """Transparent, configurable weights for the explainable match score.

    These weights are *rules*, not a trained model. They produce an
    explainable similarity index - NOT a hiring-probability prediction.
    """

    required_skills: float = 0.50
    preferred_skills: float = 0.15
    experience: float = 0.20
    education: float = 0.10
    resume_completeness: float = 0.05

    def as_dict(self) -> dict[str, float]:
        return {
            "required_skills": self.required_skills,
            "preferred_skills": self.preferred_skills,
            "experience": self.experience,
            "education": self.education,
            "resume_completeness": self.resume_completeness,
        }


SCORING_WEIGHTS = ScoringWeights()


def llm_configured() -> bool:
    """Return True when an API key for the selected provider is present."""
    if LLM_PROVIDER == "openai":
        return bool(OPENAI_API_KEY)
    # Unknown provider configured -> treat as unavailable so the app degrades
    # gracefully to the deterministic engines instead of crashing.
    return False


def mask_secret(value: str | None) -> str:
    """Return a redacted fingerprint of a secret, safe to display.

    Example: ``sk-abcd...wxyz``. Never returns the full secret.
    """
    if not value:
        return "not set"
    if len(value) <= 8:
        return "*" * len(value)
    return f"{value[:4]}...{value[-4:]}"


def active_llm_label() -> str:
    """Human-readable label describing the active AI backend."""
    if llm_configured():
        return f"{LLM_PROVIDER}:{LLM_MODEL}"
    return "deterministic-fallback (no API key configured)"
