"""Safe handling of uploaded resume files.

Design decisions:
* Uploads are written to ``data/uploads`` (git-ignored) with a sanitised name.
* File contents are never logged - only metadata (name, size) is logged.
* Any failure to read a file raises a clear, user-facing error message.
"""

from __future__ import annotations

import logging
import re
import uuid
from pathlib import Path
from typing import Union

from config.settings import UPLOAD_DIR
from utils.validators import clean_text, validate_upload

logger = logging.getLogger(__name__)

_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")


class FileHandlingError(RuntimeError):
    """Raised when an uploaded file cannot be stored or read."""


def sanitise_filename(filename: str) -> str:
    """Strip directory components and unsafe characters from a filename."""
    base = Path(filename or "upload").name
    safe = _SAFE_NAME_RE.sub("_", base).strip("._") or "upload"
    return safe[:120]


def save_upload(upload, upload_dir: Path | None = None) -> Path:
    """Persist a Streamlit ``UploadedFile`` (or a bytes-like object) to disk.

    Returns the path the file was written to. Validates extension and size
    before writing anything, so invalid uploads never touch the filesystem.
    """
    upload_dir = upload_dir or UPLOAD_DIR
    upload_dir.mkdir(parents=True, exist_ok=True)

    name = getattr(upload, "name", "upload")
    data: bytes
    if hasattr(upload, "getvalue"):
        data = upload.getvalue()
    elif hasattr(upload, "read"):
        data = upload.read()
    else:  # pragma: no cover - defensive
        raise FileHandlingError("Unsupported upload object.")

    validate_upload(name, len(data))

    safe_name = sanitise_filename(name)
    target = upload_dir / f"{uuid.uuid4().hex[:8]}_{safe_name}"
    try:
        target.write_bytes(data)
    except OSError as exc:  # pragma: no cover - disk issues
        raise FileHandlingError(f"Could not save the uploaded file: {exc}") from exc

    # Log metadata only - never the file contents.
    logger.info("Stored upload '%s' (%d bytes)", safe_name, len(data))
    return target


def extract_text(path: Union[str, Path]) -> str:
    """Extract plain text from a stored .pdf, .docx or .txt file.

    Delegates to :mod:`services.resume_parser` to avoid duplicate logic while
    keeping a single, discoverable entry point for file reading.
    """
    from services.resume_parser import extract_text_from_file

    return clean_text(extract_text_from_file(Path(path)))


def cleanup_file(path: Union[str, Path]) -> None:
    """Delete a temporary upload, ignoring the case where it already vanished."""
    try:
        Path(path).unlink(missing_ok=True)
    except OSError as exc:  # pragma: no cover - defensive
        logger.warning("Could not remove temporary file: %s", exc)
