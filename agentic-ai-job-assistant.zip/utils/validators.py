"""Input validation helpers used by the UI and by tests.

Every user-supplied value that could break an upload or a database write goes
through one of these functions first.
"""

from __future__ import annotations

import re

from config.settings import ALLOWED_EXTENSIONS, MAX_UPLOAD_BYTES, MAX_UPLOAD_MB

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(r"(\+?\d[\d\s\-().]{7,}\d)")
_YEARS_RE = re.compile(r"(\d{1,2})\s*\+?\s*(?:years|yrs?)", re.IGNORECASE)


class ValidationError(ValueError):
    """Raised when user input fails validation."""


def validate_extension(filename: str) -> str:
    """Return the lower-case extension, or raise if it is not supported."""
    if not filename or "." not in filename:
        raise ValidationError(
            f"File has no extension. Allowed types: {', '.join(ALLOWED_EXTENSIONS)}."
        )
    ext = "." + filename.rsplit(".", 1)[-1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValidationError(
            f"Unsupported file type '{ext}'. Allowed types: "
            f"{', '.join(ALLOWED_EXTENSIONS)}."
        )
    return ext


def validate_size(size_bytes: int) -> None:
    """Raise if the file is empty or larger than the configured maximum."""
    if size_bytes is None or size_bytes < 0:
        raise ValidationError("Could not determine file size.")
    if size_bytes == 0:
        raise ValidationError("The uploaded file is empty.")
    if size_bytes > MAX_UPLOAD_BYTES:
        size_mb = size_bytes / (1024 * 1024)
        raise ValidationError(
            f"File is {size_mb:.1f} MB, which exceeds the {MAX_UPLOAD_MB} MB limit. "
            "Reduce the file size or raise MAX_UPLOAD_MB in your .env file."
        )


def validate_upload(filename: str, size_bytes: int) -> str:
    """Validate filename + size together; return the normalised extension."""
    ext = validate_extension(filename)
    validate_size(size_bytes)
    return ext


def is_valid_email(value: str) -> bool:
    """True when the string looks like an email address."""
    return bool(value and _EMAIL_RE.fullmatch(value.strip()))


def extract_emails(text: str) -> list[str]:
    """Return every email address found in a block of text."""
    return _EMAIL_RE.findall(text or "")


def extract_phones(text: str) -> list[str]:
    """Return every phone-like string found in a block of text."""
    return [m.strip() for m in _PHONE_RE.findall(text or "")]


def extract_years_of_experience(text: str) -> float:
    """Return the largest 'N years' figure mentioned in the text (0.0 if none)."""
    if not text:
        return 0.0
    matches = [float(m) for m in _YEARS_RE.findall(text)]
    return max(matches) if matches else 0.0


def clean_text(text: str) -> str:
    """Normalise whitespace and strip control characters from extracted text."""
    if not text:
        return ""
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def truncate(text: str, limit: int) -> str:
    """Truncate text to ``limit`` characters, appending an ellipsis if cut."""
    if text is None:
        return ""
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."
