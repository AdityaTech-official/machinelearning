"""Dashboard page: high-level stats and recent activity."""

from __future__ import annotations

import streamlit as st

from config.settings import active_llm_label, llm_configured
from database.repository import ApplicationRepository
from ui.style import status_badge


def render(repo: ApplicationRepository) -> None:
    """Render the dashboard overview."""
    st.header("Dashboard")
    st.caption(
        "Your job-search command centre - live statistics from your local "
        "SQLite tracker."
    )

    # --- Connectivity banner ----------------------------------------- #
    if llm_configured():
        st.success(f"AI features enabled via {active_llm_label()}", icon="✅")
    else:
        st.info(
            "Running in deterministic mode (no API key configured). Every feature "
            "still works using rule-based engines; add an OPENAI_API_KEY to .env "
            "for richer AI-generated text.",
            icon="ℹ️",
        )

    total = repo.total()
    counts = repo.count_by_status()
    avg = repo.average_match_score()

    # --- KPI cards ---------------------------------------------------- #
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total applications", total)
    c2.metric("Interviews", counts.get("Interview", 0))
    c3.metric("Offers", counts.get("Offer", 0))
    c4.metric("Avg. match score", f"{avg}%" if avg else "—")

    st.divider()
    left, right = st.columns([1, 1])

    with left:
        st.subheader("Pipeline by status")
        if total == 0:
            st.caption("No applications yet. Add your first one in the Tracker.")
        else:
            for status, count in counts.items():
                st.write(f"{status_badge(status)}  **{count}**")
                progress = count / total if total else 0
                st.progress(progress)

    with right:
        st.subheader("Recent activity")
        recent = repo.recent(limit=6)
        if not recent:
            st.caption("Nothing here yet.")
        else:
            for app in recent:
                with st.container(border=True):
                    st.markdown(
                        f"**{app.role}** at *{app.company}*  \n"
                        f"{status_badge(app.status)} · {app.application_date}"
                    )

    st.divider()
    st.subheader("How this works")
    st.markdown(
        """
        1. **Resume Analyzer** - upload a PDF/DOCX and review the extracted data.
        2. **Job Analyzer** - paste a job description to get structured requirements.
        3. **Job Matcher** - see an explainable match score and skill breakdown.
        4. **Cover Letter & Skill Gap** - generate drafts and a learning plan.
        5. **Tracker** - store each application and track its status.

        Everything is stored locally in `data/applications.db`. Resume contents
        are only sent to a model when an API key is configured.
        """
    )
