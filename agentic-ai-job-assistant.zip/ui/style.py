"""Shared UI helpers: status badges, score colouring and safe reruns."""

from __future__ import annotations

import streamlit as st

_STATUS_STYLES: dict[str, tuple[str, str]] = {
    "Interested": ("#6366f1", "#eef2ff"),
    "Preparing": ("#d97706", "#fffbeb"),
    "Applied": ("#2563eb", "#eff6ff"),
    "Interview": ("#7c3aed", "#f5f3ff"),
    "Offer": ("#16a34a", "#f0fdf4"),
    "Rejected": ("#dc2626", "#fef2f2"),
}


def status_badge(status: str) -> str:
    """Return a coloured HTML badge for an application status."""
    fg, bg = _STATUS_STYLES.get(status, ("#334155", "#f1f5f9"))
    return (
        f"<span style='background:{bg};color:{fg};padding:2px 10px;"
        f"border-radius:999px;font-size:0.8rem;font-weight:600;"
        f"border:1px solid {fg}33;'>{status}</span>"
    )


def score_colour(score: float) -> str:
    """Map a score to a traffic-light colour."""
    if score >= 75:
        return "#16a34a"
    if score >= 50:
        return "#d97706"
    return "#dc2626"


def score_badge(score: float) -> str:
    """Return a coloured HTML badge for a match score."""
    colour = score_colour(score)
    label = "Strong" if score >= 75 else "Moderate" if score >= 50 else "Low"
    return (
        f"<span style='background:{colour};color:#fff;padding:4px 12px;"
        f"border-radius:8px;font-weight:700;font-size:1rem;'>"
        f"{score:.0f}% · {label}</span>"
    )


def confidence_badge(level: str) -> str:
    """Return a small badge describing confidence in a suggestion."""
    colours = {"high": "#16a34a", "medium": "#d97706", "low": "#64748b"}
    colour = colours.get(level, "#64748b")
    return (
        f"<span style='background:{colour}22;color:{colour};padding:1px 8px;"
        f"border-radius:6px;font-size:0.75rem;'>{level}</span>"
    )
