"""Cover Letter & Skill Gap Planner page."""

from __future__ import annotations

import streamlit as st

from agents.orchestrator import Orchestrator
from database.models import JobRequirements, ResumeData


def render(orchestrator: Orchestrator) -> None:
    """Render the cover-letter generator and the skill-gap planner."""
    st.header("Cover Letter & Skill Gap Planner")

    resume: ResumeData | None = st.session_state.get("resume_data")
    job: JobRequirements | None = st.session_state.get("job_data")

    if resume is None or job is None:
        st.info(
            "Analyse a resume (Resume Analyzer tab) and a job description "
            "(Job Matcher tab) first - both feed this page.",
            icon="📋",
        )
        return

    tabs = st.tabs(["Cover Letter", "Skill Gap Plan"])

    # ---------------- Cover letter ---------------- #
    with tabs[0]:
        st.subheader("Personalised cover letter")
        st.caption(
            "Generated only from your real resume and the job description. No "
            "achievements or company facts are invented - always review before sending."
        )
        if st.button("Generate cover letter", type="primary"):
            with st.spinner("Writing your draft..."):
                result = orchestrator.cover_letter(resume, job)
            if not result.ok:
                st.error(result.error, icon="🚫")
            else:
                st.session_state.cover_letter = str(result.data)
                for warning in result.warnings:
                    st.warning(warning, icon="⚠️")

        letter = st.session_state.get("cover_letter", "")
        if letter:
            edited = st.text_area("Editable draft", value=letter, height=420)
            st.download_button(
                "Download as .txt",
                data=edited,
                file_name="cover_letter.txt",
                mime="text/plain",
            )
            st.caption("Tip: use the copy icon in the top-right of the text box to copy.")

    # ---------------- Skill gap ---------------- #
    with tabs[1]:
        st.subheader("Prioritised learning plan")
        st.caption(
            "Required gaps are listed before optional recommendations. Each item "
            "explains why it matters and how to close it."
        )
        if st.button("Generate learning plan", type="primary"):
            with st.spinner("Building your plan..."):
                match = st.session_state.get("match_data")
                result = orchestrator.skill_gap(resume, job, match)
            if not result.ok:
                st.error(result.error, icon="🚫")
            else:
                st.session_state.skill_plan = result.data
                for warning in result.warnings:
                    st.warning(warning, icon="⚠️")

        plan = st.session_state.get("skill_plan")
        if plan:
            st.info(plan.summary, icon="🎯")
            for gap in plan.gaps:
                badge = "🔴 Required" if gap.importance == "Required" else "🟡 Optional"
                with st.container(border=True):
                    st.markdown(f"**{gap.priority}. {gap.skill}**  {badge}")
                    st.caption(gap.why_it_matters)
                    st.markdown("**Learning steps**")
                    for step in gap.learning_steps:
                        st.markdown(f"- {step}")
                    st.markdown(f"**Project idea:** {gap.project_suggestion}")
