"""Resume Analyzer page: upload, extract, review, correct, improve."""

from __future__ import annotations

import streamlit as st

from agents.orchestrator import Orchestrator
from database.models import ResumeData
from ui.style import confidence_badge
from utils.file_handler import FileHandlingError, save_upload
from utils.validators import ValidationError, validate_upload


def _parse_skills(raw: str) -> list[str]:
    """Convert a comma-separated string into a clean skill list."""
    return [s.strip() for s in raw.split(",") if s.strip()]


def render(orchestrator: Orchestrator) -> None:
    """Render the resume-analyzer workflow."""
    st.header("Resume Analyzer")
    st.caption(
        "Upload a PDF or DOCX resume. We extract the key sections, then you can "
        "review and correct anything before using it elsewhere."
    )

    if "resume_data" not in st.session_state:
        st.session_state.resume_data = None

    # ------------------------------------------------------------------ #
    # Upload
    # ------------------------------------------------------------------ #
    upload = st.file_uploader(
        "Upload resume (PDF or DOCX, max 5 MB)",
        type=["pdf", "docx", "txt"],
        help="Text-based files only. Scanned image PDFs cannot be parsed.",
    )
    col_a, col_b = st.columns([1, 3])
    analyse = col_a.button("Analyse resume", type="primary", use_container_width=True)

    if analyse:
        if upload is None:
            st.warning("Please choose a file first.", icon="⚠️")
        else:
            try:
                validate_upload(upload.name, len(upload.getvalue()))
                with st.spinner("Extracting and analysing your resume..."):
                    path = save_upload(upload)
                    result = orchestrator.analyse_resume(file_path=path)
                if not result.ok:
                    st.error(result.error, icon="🚫")
                else:
                    st.session_state.resume_data = result.data
                    st.session_state.resume_improvements = orchestrator.last_improvements
                    st.session_state.resume_used_llm = result.used_llm
                    for warning in result.warnings:
                        st.warning(warning, icon="⚠️")
                    st.success("Resume analysed successfully.", icon="✅")
            except (ValidationError, FileHandlingError) as exc:
                st.error(str(exc), icon="🚫")
            except Exception as exc:  # noqa: BLE001
                st.error(f"Unexpected error while analysing the resume: {exc}", icon="🚫")

    resume: ResumeData | None = st.session_state.get("resume_data")
    if resume is None:
        st.info("Upload a resume and click **Analyse resume** to begin.", icon="📄")
        return

    engine = "LLM" if st.session_state.get("resume_used_llm") else "rule-based engine"
    st.caption(f"Parsed with the {engine}.")

    # ------------------------------------------------------------------ #
    # Review & correct (editable form)
    # ------------------------------------------------------------------ #
    st.subheader("Review and correct extracted data")
    with st.form("resume_edit_form"):
        col1, col2, col3 = st.columns(3)
        name = col1.text_input("Name", value=resume.name)
        email = col2.text_input("Email", value=resume.email)
        phone = col3.text_input("Phone", value=resume.phone)

        summary = st.text_area("Summary", value=resume.summary, height=80)

        skills_text = st.text_input(
            "Skills (comma separated)",
            value=", ".join(resume.skills),
        )

        st.markdown("**Education**")
        edu_text = st.text_area(
            "One entry per line (degree | institution | year)",
            value="\n".join(
                f"{e.degree} | {e.institution} | {e.year or ''}" for e in resume.education
            ),
            height=90,
        )

        st.markdown("**Experience**")
        exp_text = st.text_area(
            "One entry per line (title | company | duration)",
            value="\n".join(
                f"{e.title} | {e.company} | {e.duration}" for e in resume.experience
            ),
            height=90,
        )

        st.markdown("**Projects**")
        proj_text = st.text_area(
            "One entry per line (name | description)",
            value="\n".join(f"{p.name} | {p.description}" for p in resume.projects),
            height=90,
        )

        st.markdown("**Certifications**")
        cert_text = st.text_area(
            "One entry per line (name | issuer | year)",
            value="\n".join(
                f"{c.name} | {c.issuer} | {c.year or ''}" for c in resume.certifications
            ),
            height=80,
        )

        submitted = st.form_submit_button("Save corrections", type="primary")

    if submitted:
        from database.models import Certification, Education, Experience, Project

        resume.name = name
        resume.email = email
        resume.phone = phone
        resume.summary = summary
        resume.skills = _parse_skills(skills_text)

        resume.education = [
            Education(
                degree=parts[0].strip(),
                institution=parts[1].strip() if len(parts) > 1 else "",
                year=parts[2].strip() if len(parts) > 2 else None,
            )
            for line in edu_text.splitlines()
            if line.strip() and (parts := [p.strip() for p in line.split("|")])
        ]
        resume.experience = [
            Experience(
                title=parts[0].strip(),
                company=parts[1].strip() if len(parts) > 1 else "",
                duration=parts[2].strip() if len(parts) > 2 else "",
            )
            for line in exp_text.splitlines()
            if line.strip() and (parts := [p.strip() for p in line.split("|")])
        ]
        resume.projects = [
            Project(
                name=parts[0].strip(),
                description=parts[1].strip() if len(parts) > 1 else "",
            )
            for line in proj_text.splitlines()
            if line.strip() and (parts := [p.strip() for p in line.split("|")])
        ]
        resume.certifications = [
            Certification(
                name=parts[0].strip(),
                issuer=parts[1].strip() if len(parts) > 1 else "",
                year=parts[2].strip() if len(parts) > 2 else None,
            )
            for line in cert_text.splitlines()
            if line.strip() and (parts := [p.strip() for p in line.split("|")])
        ]
        st.session_state.resume_data = resume
        st.success("Corrections saved to this session.", icon="✅")

    # ------------------------------------------------------------------ #
    # Structured summary + improvements
    # ------------------------------------------------------------------ #
    st.divider()
    tabs = st.tabs(["Structured view", "Resume improvements", "Raw text"])
    with tabs[0]:
        _render_structured(resume)
    with tabs[1]:
        _render_improvements(st.session_state.get("resume_improvements", []))
    with tabs[2]:
        st.text_area("Extracted text", value=resume.raw_text, height=300, disabled=True)


def _render_structured(resume: ResumeData) -> None:
    """Render a card-based structured view of the resume."""
    cols = st.columns(2)
    with cols[0]:
        with st.container(border=True):
            st.markdown("#### Skills")
            if resume.skills:
                st.write(" · ".join(resume.skills))
            else:
                st.caption("None detected.")
        with st.container(border=True):
            st.markdown("#### Experience")
            if resume.experience:
                for exp in resume.experience:
                    st.markdown(f"**{exp.title}** — {exp.company or '—'}")
            else:
                st.caption("None detected.")
    with cols[1]:
        with st.container(border=True):
            st.markdown("#### Education")
            if resume.education:
                for edu in resume.education:
                    st.markdown(f"**{edu.degree}**")
            else:
                st.caption("None detected.")
        with st.container(border=True):
            st.markdown("#### Projects")
            if resume.projects:
                for proj in resume.projects:
                    st.markdown(f"**{proj.name}**")
            else:
                st.caption("None detected.")


def _render_improvements(improvements: list) -> None:
    """Render original vs. suggested bullets side by side."""
    if not improvements:
        st.info(
            "No bullet-point improvements suggested. This usually means your "
            "bullets are already well-phrased, or too few were detected.",
            icon="👍",
        )
        return
    st.caption(
        "Suggestions rephrase your own words for clarity. No new metrics, "
        "results or technologies are ever added."
    )
    for imp in improvements:
        with st.container(border=True):
            c1, c2 = st.columns(2)
            with c1:
                st.markdown("**Original**")
                st.write(imp.original)
            with c2:
                st.markdown(f"**Suggested** {confidence_badge(imp.confidence)}")
                st.write(imp.improved)
            st.caption(f"Section: {imp.section} · {imp.rationale}")
