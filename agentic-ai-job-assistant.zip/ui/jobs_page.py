"""Job Matcher page: analyze a JD, match against the resume, show reasoning."""

from __future__ import annotations

import streamlit as st

from agents.orchestrator import Orchestrator
from database.models import ApplicationRecord, JobRequirements, ResumeData
from ui.style import score_badge, status_badge


def render(orchestrator: Orchestrator) -> None:
    """Render the job-analysis and matching workflow."""
    st.header("Job Matcher")
    st.caption(
        "Paste a job description, extract its requirements, and compare them "
        "against your analysed resume with a fully explainable score."
    )

    resume: ResumeData | None = st.session_state.get("resume_data")

    jd_text = st.text_area(
        "Paste the job description",
        height=260,
        placeholder="Paste the full job description here...",
        key="jd_text_area",
    )

    col1, col2, col3 = st.columns(3)
    analyze_job = col1.button("1. Analyze job", use_container_width=True)
    run_match = col2.button("2. Match resume", type="primary", use_container_width=True)
    run_full = col3.button("3. Full pipeline", use_container_width=True)

    if analyze_job or run_match or run_full:
        if not jd_text.strip():
            st.warning("Please paste a job description first.", icon="⚠️")
            st.stop()
        with st.spinner("Analysing the job description..."):
            job_result = orchestrator.analyse_job(jd_text)
        if not job_result.ok:
            st.error(job_result.error, icon="🚫")
            st.stop()
        st.session_state.job_data = job_result.data
        for warning in job_result.warnings:
            st.warning(warning, icon="⚠️")

    job: JobRequirements | None = st.session_state.get("job_data")
    if job is None:
        st.info("Analyze a job description to see its structured requirements.", icon="📋")
        return

    _render_job(job)

    if run_match or run_full:
        if resume is None:
            st.error(
                "No analysed resume found. Go to the **Resume Analyzer** tab and "
                "analyze your resume first.",
                icon="🚫",
            )
            return
        with st.spinner("Computing the explainable match..."):
            if run_full:
                pipeline = orchestrator.run_full_pipeline(resume, job)
                st.session_state.match_data = pipeline.match
                st.session_state.cover_letter = pipeline.cover_letter
                st.session_state.skill_plan = pipeline.skill_gap
                for warning in pipeline.warnings:
                    st.warning(warning, icon="⚠️")
            else:
                match_result = orchestrator.match(resume, job)
                if not match_result.ok:
                    st.error(match_result.error, icon="🚫")
                    return
                st.session_state.match_data = match_result.data
                for warning in match_result.warnings:
                    st.warning(warning, icon="⚠️")

    match = st.session_state.get("match_data")
    if match is not None:
        _render_match(match)
        _render_save(match, orchestrator)


def _render_job(job: JobRequirements) -> None:
    """Render the parsed job requirements in tabs."""
    st.divider()
    st.subheader("Extracted requirements")
    tabs = st.tabs(["Required", "Preferred", "Responsibilities", "Qualifications"])
    with tabs[0]:
        st.write(", ".join(job.required_skills) or "None detected")
        if job.experience_required:
            st.caption(f"Experience: {job.experience_required}")
        if job.education_required:
            st.caption(f"Education: {job.education_required}")
    with tabs[1]:
        st.write(", ".join(job.preferred_skills) or "None detected")
    with tabs[2]:
        for line in job.responsibilities or ["None detected"]:
            st.markdown(f"- {line}")
    with tabs[3]:
        for line in job.qualifications or ["None detected"]:
            st.markdown(f"- {line}")


def _render_match(match) -> None:
    """Render the score, breakdown and skill categories."""
    st.divider()
    st.subheader("Match result")
    c1, c2 = st.columns([1, 2])
    with c1:
        st.markdown(score_badge(match.overall_score), unsafe_allow_html=True)
        st.metric("Overall match", f"{match.overall_score:.1f}%")
    with c2:
        st.info(match.disclaimer, icon="ℹ️")
        st.caption(match.explanation)

    st.markdown("**Score breakdown**")
    for label, value in match.breakdown.items():
        st.write(f"{label}: **{value:.1f}%**")
        st.progress(min(value / 100, 1.0))

    st.divider()
    b1, b2, b3, b4 = st.columns(4)
    with b1:
        st.markdown(f"### ✅ Matched ({len(match.matched)})")
        for item in match.matched:
            with st.container(border=True):
                st.markdown(f"**{item.skill}**")
                st.caption(item.reason)
    with b2:
        st.markdown(f"### ⚠️ Partial ({len(match.partial)})")
        for item in match.partial:
            with st.container(border=True):
                st.markdown(f"**{item.skill}**")
                st.caption(item.evidence)
                st.caption(item.reason)
    with b3:
        st.markdown(f"### ❌ Missing ({len(match.missing)})")
        for item in match.missing:
            with st.container(border=True):
                st.markdown(f"**{item.skill}**")
                st.caption(item.reason)
    with b4:
        st.markdown(f"### ❓ Unsupported ({len(match.unsupported)})")
        for item in match.unsupported:
            with st.container(border=True):
                st.markdown(f"**{item.skill}**")
                st.caption(item.reason)


def _render_save(match, orchestrator: Orchestrator) -> None:
    """Allow the user to save the match as a tracked application."""
    st.divider()
    st.subheader("Save to tracker")
    job: JobRequirements = st.session_state.get("job_data")
    with st.form("save_match_form"):
        col1, col2 = st.columns(2)
        company = col1.text_input("Company", value=job.company or "")
        role = col2.text_input("Role", value=job.title or "")
        confirmed = st.checkbox(
            "I confirm I want to save this application record locally."
        )
        save = st.form_submit_button("Save application", type="primary")

    if save:
        if not company.strip() or not role.strip():
            st.warning("Company and role are both required.", icon="⚠️")
            return
        record = ApplicationRecord(
            company=company.strip(),
            role=role.strip(),
            job_description=st.session_state.get("jd_text_area", "")[:5000],
            status="Preparing",
            match_score=match.overall_score,
        )
        ok, message = orchestrator.save_application(record, confirmed=confirmed)
        if ok:
            st.success(message, icon="✅")
        else:
            st.warning(message, icon="⚠️")
