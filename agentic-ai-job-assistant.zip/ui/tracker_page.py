"""Application Tracker page: full CRUD, search, filters and statistics."""

from __future__ import annotations

import streamlit as st

from agents.orchestrator import Orchestrator
from config.settings import APPLICATION_STATUSES
from database.models import ApplicationRecord
from database.repository import ApplicationRepository
from ui.style import status_badge


def render(repo: ApplicationRepository, orchestrator: Orchestrator) -> None:
    """Render the application tracker."""
    st.header("Application Tracker")
    st.caption(
        "Every record is stored locally in SQLite (`data/applications.db`). "
        "Nothing is sent anywhere."
    )

    tabs = st.tabs(["Add application", "Browse & edit", "Search", "Statistics"])

    # ---------------- Add ---------------- #
    with tabs[0]:
        with st.form("add_application_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            company = c1.text_input("Company *")
            role = c2.text_input("Role *")
            c3, c4 = st.columns(2)
            app_date = c3.date_input("Application date")
            status = c4.selectbox("Status", APPLICATION_STATUSES, index=0)
            jd = st.text_area("Job description (optional)", height=140)
            notes = st.text_area("Notes (optional)", height=80)
            score = st.number_input(
                "Match score % (optional)", min_value=0.0, max_value=100.0, value=0.0
            )
            confirmed = st.checkbox("I confirm I want to save this record locally.")
            submitted = st.form_submit_button("Save application", type="primary")

        if submitted:
            if not company.strip() or not role.strip():
                st.warning("Company and role are required.", icon="⚠️")
            else:
                try:
                    record = ApplicationRecord(
                        company=company,
                        role=role,
                        job_description=jd,
                        application_date=app_date.isoformat(),
                        status=status,
                        notes=notes,
                        match_score=score or None,
                    )
                except ValueError as exc:
                    st.error(f"Invalid input: {exc}", icon="🚫")
                    return
                ok, message = orchestrator.save_application(record, confirmed=confirmed)
                if ok:
                    st.success(message, icon="✅")
                else:
                    st.warning(message, icon="⚠️")

    # ---------------- Browse & edit ---------------- #
    with tabs[1]:
        rows = repo.list_all()
        if not rows:
            st.info("No applications stored yet.", icon="📭")
        else:
            label_map = {f"#{r.id} · {r.company} — {r.role}": r for r in rows}
            choice = st.selectbox("Select an application", list(label_map.keys()))
            selected = label_map[choice]
            _render_editor(repo, selected)

    # ---------------- Search ---------------- #
    with tabs[2]:
        term = st.text_input("Search company, role, notes or description")
        status_filter = st.selectbox("Filter by status", ["All", *APPLICATION_STATUSES])
        results = repo.search(term) if term.strip() else repo.list_all(
            None if status_filter == "All" else status_filter
        )
        if term.strip() and status_filter != "All":
            results = [r for r in results if r.status == status_filter]

        if not results:
            st.caption("No matching applications.")
        else:
            st.dataframe(
                [
                    {
                        "ID": r.id,
                        "Company": r.company,
                        "Role": r.role,
                        "Status": r.status,
                        "Date": r.application_date,
                        "Match %": r.match_score if r.match_score is not None else "",
                        "Notes": (r.notes or "")[:60],
                    }
                    for r in results
                ],
                use_container_width=True,
                hide_index=True,
            )

    # ---------------- Statistics ---------------- #
    with tabs[3]:
        counts = repo.count_by_status()
        c1, c2, c3 = st.columns(3)
        c1.metric("Total", repo.total())
        c2.metric("Interviews", counts.get("Interview", 0))
        c3.metric("Avg. match", f"{repo.average_match_score()}%")
        st.divider()
        st.markdown("**Status distribution**")
        for status, count in counts.items():
            st.write(f"{status_badge(status)}  **{count}**", unsafe_allow_html=True)

        st.divider()
        st.markdown("**Conversion funnel**")
        total = max(repo.total(), 1)
        for status in ("Applied", "Interview", "Offer"):
            n = counts.get(status, 0)
            st.write(f"{status}: {n} ({n / total * 100:.0f}% of all records)")
            st.progress(min(n / total, 1.0))


def _render_editor(repo: ApplicationRepository, selected: ApplicationRecord) -> None:
    """Inline editor for one record, plus a delete action."""
    with st.form(f"edit_{selected.id}"):
        c1, c2 = st.columns(2)
        company = c1.text_input("Company", value=selected.company)
        role = c2.text_input("Role", value=selected.role)
        c3, c4 = st.columns(2)
        app_date = c3.text_input("Application date", value=selected.application_date)
        status = c4.selectbox(
            "Status",
            APPLICATION_STATUSES,
            index=APPLICATION_STATUSES.index(selected.status),
        )
        notes = st.text_area("Notes", value=selected.notes or "", height=80)
        jd = st.text_area("Job description", value=selected.job_description or "", height=120)
        col_a, col_b = st.columns(2)
        save = col_a.form_submit_button("Update record", type="primary")
        delete = col_b.form_submit_button("Delete record")

    if save:
        try:
            repo.update(
                selected.id,
                company=company,
                role=role,
                application_date=app_date,
                status=status,
                notes=notes,
                job_description=jd,
            )
            st.success(f"Updated application #{selected.id}.", icon="✅")
            st.rerun()
        except ValueError as exc:
            st.error(f"Invalid input: {exc}", icon="🚫")

    if delete:
        if repo.delete(selected.id):
            st.success(f"Deleted application #{selected.id}.", icon="🗑️")
            st.rerun()
        else:
            st.warning("Record not found.", icon="⚠️")
