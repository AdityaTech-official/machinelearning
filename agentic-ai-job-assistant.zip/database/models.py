"""Pydantic models that define every structured payload in the application.

Using Pydantic here is deliberate: every LLM response is validated against one
of these schemas before it reaches the UI, so malformed model output can never
silently corrupt the user's data.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from pydantic import BaseModel, Field, field_validator

from config.settings import APPLICATION_STATUSES


# --------------------------------------------------------------------------- #
# Resume models
# --------------------------------------------------------------------------- #
class Education(BaseModel):
    """A single education entry."""

    degree: str = ""
    institution: str = ""
    year: Optional[str] = None
    details: str = ""


class Experience(BaseModel):
    """A single work / internship experience entry."""

    title: str = ""
    company: str = ""
    duration: str = ""
    description: list[str] = Field(default_factory=list)


class Project(BaseModel):
    """A single project entry."""

    name: str = ""
    description: str = ""
    technologies: list[str] = Field(default_factory=list)


class Certification(BaseModel):
    """A single certification entry."""

    name: str = ""
    issuer: str = ""
    year: Optional[str] = None


class ResumeData(BaseModel):
    """Everything we extract from a resume, in a review-friendly structure."""

    name: str = ""
    email: str = ""
    phone: str = ""
    summary: str = ""
    education: list[Education] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    experience: list[Experience] = Field(default_factory=list)
    projects: list[Project] = Field(default_factory=list)
    certifications: list[Certification] = Field(default_factory=list)
    raw_text: str = ""

    @field_validator("skills", mode="before")
    @classmethod
    def _clean_skills(cls, value: object) -> list[str]:
        """De-duplicate skills case-insensitively while preserving order."""
        if not isinstance(value, list):
            return []
        seen: set[str] = set()
        out: list[str] = []
        for item in value:
            text = str(item).strip()
            if text and text.lower() not in seen:
                seen.add(text.lower())
                out.append(text)
        return out

    def is_empty(self) -> bool:
        """True when nothing meaningful was extracted."""
        return not any(
            [self.name, self.email, self.skills, self.education,
             self.experience, self.projects, self.certifications]
        )


# --------------------------------------------------------------------------- #
# Job description models
# --------------------------------------------------------------------------- #
class JobRequirements(BaseModel):
    """Structured representation of a pasted job description."""

    title: str = ""
    company: str = ""
    required_skills: list[str] = Field(default_factory=list)
    preferred_skills: list[str] = Field(default_factory=list)
    responsibilities: list[str] = Field(default_factory=list)
    qualifications: list[str] = Field(default_factory=list)
    experience_required: str = ""
    education_required: str = ""

    def is_empty(self) -> bool:
        return not any(
            [self.required_skills, self.preferred_skills,
             self.responsibilities, self.qualifications]
        )


# --------------------------------------------------------------------------- #
# Matching / scoring models
# --------------------------------------------------------------------------- #
class SkillMatch(BaseModel):
    """One skill judgement with the evidence that produced it."""

    skill: str
    evidence: str = ""
    reason: str = ""


class MatchResult(BaseModel):
    """Explainable match output. Never a hiring-probability prediction."""

    overall_score: float = 0.0
    matched: list[SkillMatch] = Field(default_factory=list)
    partial: list[SkillMatch] = Field(default_factory=list)
    missing: list[SkillMatch] = Field(default_factory=list)
    unsupported: list[SkillMatch] = Field(default_factory=list)
    breakdown: dict[str, float] = Field(default_factory=dict)
    explanation: str = ""
    disclaimer: str = (
        "This score is a transparent similarity index computed from keyword and "
        "rule overlap. It is NOT a prediction of hiring probability and does "
        "not represent any employer's decision process."
    )


# --------------------------------------------------------------------------- #
# Skill-gap models
# --------------------------------------------------------------------------- #
class SkillGapItem(BaseModel):
    """A single prioritised learning recommendation."""

    skill: str
    importance: str = "Required"  # "Required" | "Preferred"
    why_it_matters: str = ""
    priority: int = 1
    learning_steps: list[str] = Field(default_factory=list)
    project_suggestion: str = ""


class SkillGapPlan(BaseModel):
    """The full, prioritised learning plan."""

    target_role: str = ""
    gaps: list[SkillGapItem] = Field(default_factory=list)
    summary: str = ""


# --------------------------------------------------------------------------- #
# Resume-improvement models
# --------------------------------------------------------------------------- #
class BulletImprovement(BaseModel):
    """Original vs. suggested bullet point, shown side by side."""

    section: str = ""
    original: str = ""
    improved: str = ""
    rationale: str = ""
    confidence: str = "medium"


# --------------------------------------------------------------------------- #
# Application tracker model
# --------------------------------------------------------------------------- #
class ApplicationRecord(BaseModel):
    """A persisted job-application row."""

    id: Optional[int] = None
    company: str
    role: str
    job_description: str = ""
    application_date: str = Field(default_factory=lambda: date.today().isoformat())
    status: str = "Interested"
    notes: str = ""
    match_score: Optional[float] = None

    @field_validator("status")
    @classmethod
    def _valid_status(cls, value: str) -> str:
        if value not in APPLICATION_STATUSES:
            raise ValueError(
                f"status must be one of {APPLICATION_STATUSES}, got {value!r}"
            )
        return value

    @field_validator("company", "role")
    @classmethod
    def _not_blank(cls, value: str) -> str:
        if not value or not value.strip():
            raise ValueError("field cannot be blank")
        return value.strip()
