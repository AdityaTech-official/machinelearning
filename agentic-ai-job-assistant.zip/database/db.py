"""SQLite connection handling and schema initialisation.

The database is created automatically on first import/use; the user never has
to run a migration by hand. All access goes through this module so that the
connection settings (row factory, foreign keys) stay consistent.
"""

from __future__ import annotations

import logging
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from config.settings import DB_PATH

logger = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS applications (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    company           TEXT    NOT NULL,
    role              TEXT    NOT NULL,
    job_description   TEXT    DEFAULT '',
    application_date  TEXT    NOT NULL,
    status            TEXT    NOT NULL DEFAULT 'Interested',
    notes             TEXT    DEFAULT '',
    match_score       REAL,
    created_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    updated_at        TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_applications_company ON applications(company);
CREATE INDEX IF NOT EXISTS idx_applications_date ON applications(application_date);
"""


def _resolve_db_path(db_path: Path | str | None = None) -> Path:
    """Resolve the database path and ensure its parent directory exists."""
    path = Path(db_path) if db_path is not None else DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_connection(db_path: Path | str | None = None) -> sqlite3.Connection:
    """Open a new SQLite connection with sensible defaults.

    ``check_same_thread=False`` is required because Streamlit can call into the
    database from a different thread than the one that created the connection.
    """
    conn = sqlite3.connect(str(_resolve_db_path(db_path)), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


@contextmanager
def connect(db_path: Path | str | None = None) -> Iterator[sqlite3.Connection]:
    """Context manager that commits on success, rolls back on error, closes always."""
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(db_path: Path | str | None = None) -> Path:
    """Create the schema if it does not exist. Idempotent and safe to call often."""
    path = _resolve_db_path(db_path)
    with connect(path) as conn:
        conn.executescript(SCHEMA)
    logger.info("Database initialised at %s", path)
    return path


if __name__ == "__main__":  # pragma: no cover - manual convenience
    logging.basicConfig(level=logging.INFO)
    created = init_db()
    print(f"Database ready: {created}")
