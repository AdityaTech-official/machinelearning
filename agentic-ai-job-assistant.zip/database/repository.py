"""Repository layer: all CRUD for application records lives here.

Keeping SQL in one place means the UI never talks to SQLite directly, which
makes the whole tracker easy to unit-test against a temporary database.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from config.settings import APPLICATION_STATUSES
from database.db import connect, init_db
from database.models import ApplicationRecord


class ApplicationRepository:
    """Data-access object for the ``applications`` table."""

    def __init__(self, db_path: Path | str | None = None) -> None:
        self.db_path = db_path
        init_db(db_path)

    # ------------------------------------------------------------------ #
    # Create
    # ------------------------------------------------------------------ #
    def create(self, record: ApplicationRecord) -> int:
        """Insert a new application and return its generated id."""
        with connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO applications
                    (company, role, job_description, application_date,
                     status, notes, match_score)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record.company,
                    record.role,
                    record.job_description,
                    record.application_date,
                    record.status,
                    record.notes,
                    record.match_score,
                ),
            )
            return int(cursor.lastrowid)

    # ------------------------------------------------------------------ #
    # Read
    # ------------------------------------------------------------------ #
    def get(self, application_id: int) -> Optional[ApplicationRecord]:
        """Fetch a single application by id, or None if it does not exist."""
        with connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM applications WHERE id = ?", (application_id,)
            ).fetchone()
        return self._row_to_model(row) if row else None

    def list_all(self, status: str | None = None) -> list[ApplicationRecord]:
        """Return every application, newest first, optionally filtered by status."""
        query = "SELECT * FROM applications"
        params: tuple[Any, ...] = ()
        if status and status in APPLICATION_STATUSES:
            query += " WHERE status = ?"
            params = (status,)
        query += " ORDER BY application_date DESC, id DESC"
        with connect(self.db_path) as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_model(r) for r in rows]

    def search(self, term: str) -> list[ApplicationRecord]:
        """Case-insensitive search across company, role, notes and description."""
        pattern = f"%{term.strip().lower()}%"
        with connect(self.db_path) as conn:
            rows = conn.execute(
                """
                SELECT * FROM applications
                WHERE lower(company) LIKE ?
                   OR lower(role) LIKE ?
                   OR lower(notes) LIKE ?
                   OR lower(job_description) LIKE ?
                ORDER BY application_date DESC, id DESC
                """,
                (pattern, pattern, pattern, pattern),
            ).fetchall()
        return [self._row_to_model(r) for r in rows]

    # ------------------------------------------------------------------ #
    # Update / Delete
    # ------------------------------------------------------------------ #
    def update(self, application_id: int, **fields: Any) -> bool:
        """Update the given columns and refresh ``updated_at``. True on success."""
        allowed = {
            "company", "role", "job_description", "application_date",
            "status", "notes", "match_score",
        }
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return False
        if "status" in updates and updates["status"] not in APPLICATION_STATUSES:
            raise ValueError(f"Invalid status: {updates['status']!r}")

        assignments = ", ".join(f"{col} = ?" for col in updates)
        values = list(updates.values())
        values.append(datetime.now().isoformat(timespec="seconds"))
        values.append(application_id)

        with connect(self.db_path) as conn:
            cursor = conn.execute(
                f"UPDATE applications SET {assignments}, updated_at = ? WHERE id = ?",
                values,
            )
            return cursor.rowcount > 0

    def delete(self, application_id: int) -> bool:
        """Delete one application. True when a row was removed."""
        with connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM applications WHERE id = ?", (application_id,)
            )
            return cursor.rowcount > 0

    # ------------------------------------------------------------------ #
    # Aggregates for the dashboard
    # ------------------------------------------------------------------ #
    def count_by_status(self) -> dict[str, int]:
        """Return a count for every status, including zero-count statuses."""
        result = {status: 0 for status in APPLICATION_STATUSES}
        with connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT status, COUNT(*) AS n FROM applications GROUP BY status"
            ).fetchall()
        for row in rows:
            result[row["status"]] = row["n"]
        return result

    def total(self) -> int:
        """Total number of stored applications."""
        with connect(self.db_path) as conn:
            row = conn.execute("SELECT COUNT(*) AS n FROM applications").fetchone()
        return int(row["n"]) if row else 0

    def average_match_score(self) -> float:
        """Mean match score across rows that have one, else 0.0."""
        with connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT AVG(match_score) AS avg_score FROM applications "
                "WHERE match_score IS NOT NULL"
            ).fetchone()
        return round(float(row["avg_score"]), 1) if row and row["avg_score"] else 0.0

    def recent(self, limit: int = 5) -> list[ApplicationRecord]:
        """Most recently updated applications, for the dashboard activity feed."""
        with connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM applications ORDER BY updated_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row_to_model(r) for r in rows]

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _row_to_model(row: Any) -> ApplicationRecord:
        """Convert a sqlite3.Row into an ApplicationRecord."""
        return ApplicationRecord(
            id=row["id"],
            company=row["company"],
            role=row["role"],
            job_description=row["job_description"] or "",
            application_date=row["application_date"],
            status=row["status"],
            notes=row["notes"] or "",
            match_score=row["match_score"],
        )
