"""Skill-gap agent: prioritised, evidence-based learning plan."""

from __future__ import annotations

import logging

from agents.resume_agent import AgentResult
from database.models import JobRequirements, MatchResult, ResumeData, SkillGapItem, SkillGapPlan
from services.llm_service import LLMService

logger = logging.getLogger(__name__)

# Practical exercise / project hints per skill family.
LEARNING_HINTS: dict[str, tuple[list[str], str]] = {
    "Python": (
        ["Complete a structured Python refresher covering OOP and typing.",
         "Build a CLI tool and add pytest tests."],
        "Automate a repetitive task (e.g. report generation) in Python.",
    ),
    "SQL": (
        ["Study joins, subqueries and window functions.",
         "Practise on a public dataset with 20+ queries."],
        "Build a small analytics dashboard backed by a SQL database.",
    ),
    "React": (
        ["Revisit components, props, hooks and state management.",
         "Complete an official tutorial and rebuild it from scratch."],
        "Create a task-manager SPA with reusable components and routing.",
    ),
    "Docker": (
        ["Learn images, containers, volumes and networking.",
         "Write multi-stage Dockerfiles for an existing app."],
        "Containerise your project and add a compose file with a database.",
    ),
    "AWS": (
        ["Cover core services: EC2, S3, IAM, Lambda and RDS.",
         "Follow free-tier labs to deploy a simple web app."],
        "Deploy a full-stack app on AWS with a documented architecture.",
    ),
    "Machine Learning": (
        ["Study supervised learning, evaluation metrics and cross-validation.",
         "Implement regression and classification from scratch and with scikit-learn."],
        "Build an end-to-end ML pipeline with data cleaning and evaluation.",
    ),
    "Django": (
        ["Learn models, views, templates and the ORM.",
         "Follow the official tutorial end-to-end."],
        "Build a blog or inventory app with authentication and tests.",
    ),
    "FastAPI": (
        ["Learn routing, Pydantic models and dependency injection.",
         "Add validation and error handling to a small API."],
        "Build a REST API with a database, auth and OpenAPI docs.",
    ),
    "Kubernetes": (
        ["Understand pods, deployments, services and config maps.",
         "Run a local cluster with minikube."],
        "Deploy a multi-service app to a local cluster with a manifest set.",
    ),
    "LangChain": (
        ["Study chains, tools, memory and structured output.",
         "Build a small RAG pipeline over your own notes."],
        "Create an LLM app that answers questions over a local document set.",
    ),
}

_DEFAULT_HINTS = (
    ["Find one authoritative tutorial or documentation set and work through it.",
     "Apply the skill in a small, time-boxed exercise with a clear deliverable."],
    "Build a focused mini-project that demonstrates this skill end-to-end.",
)


class SkillGapAgent:
    """Turns missing/partial skills into a prioritised learning plan."""

    name = "SkillGapAgent"

    def __init__(self, llm: LLMService | None = None) -> None:
        self.llm = llm or LLMService()

    def run(
        self,
        resume: ResumeData,
        job: JobRequirements,
        match: MatchResult | None = None,
    ) -> AgentResult:
        """Build a :class:`SkillGapPlan` from the match result."""
        if job is None or job.is_empty():
            return AgentResult(ok=False, error="A parsed job description is required.")

        required = set(job.required_skills)
        gaps: list[SkillGapItem] = []
        priority = 1

        if match is not None:
            # Missing REQUIRED skills are the highest priority.
            for item in match.missing:
                if item.skill in required or item.skill in job.required_skills:
                    gaps.append(self._build_item(item.skill, "Required", priority))
                    priority += 1
            for item in match.partial:
                if item.skill in required or item.skill in job.required_skills:
                    gaps.append(self._build_item(item.skill, "Required", priority))
                    priority += 1
            for item in match.missing + match.partial:
                if not any(g.skill == item.skill for g in gaps):
                    gaps.append(self._build_item(item.skill, "Preferred", priority))
                    priority += 1
        else:
            for skill in job.required_skills:
                if skill.lower() not in {s.lower() for s in resume.skills}:
                    gaps.append(self._build_item(skill, "Required", priority))
                    priority += 1

        summary = (
            f"{len([g for g in gaps if g.importance == 'Required'])} required and "
            f"{len([g for g in gaps if g.importance == 'Preferred'])} optional skill "
            f"gaps identified for the {job.title or 'target'} role. Focus on the "
            f"required gaps first - they carry the most weight in matching."
        )

        plan = SkillGapPlan(target_role=job.title, gaps=gaps[:12], summary=summary)
        warnings: list[str] = []
        if not gaps:
            warnings.append(
                "No skill gaps detected against this job description. Consider "
                "deepening existing skills with advanced projects."
            )
        return AgentResult(
            ok=True, data=plan, warnings=warnings, used_llm=self.llm.available
        )

    def _build_item(self, skill: str, importance: str, priority: int) -> SkillGapItem:
        """Create one learning recommendation for a skill."""
        canonical = skill.strip()
        steps, project = LEARNING_HINTS.get(canonical, _DEFAULT_HINTS)
        why = (
            f"'{canonical}' is explicitly listed as a {importance.lower()} skill "
            f"for this role. Demonstrating it removes a direct gap between your "
            f"resume and the job description."
        )
        return SkillGapItem(
            skill=canonical,
            importance=importance,
            why_it_matters=why,
            priority=priority,
            learning_steps=list(steps),
            project_suggestion=project,
        )
