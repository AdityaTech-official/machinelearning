"""Resume analysis agent.

Wraps the resume parsing service as a first-class agent with a single
``run`` entry point, so the orchestrator can treat all agents uniformly.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from database.models import BulletImprovement, ResumeData
from services.llm_service import LLMService
from services.resume_parser import extract_text_from_file, parse_resume

logger = logging.getLogger(__name__)


@dataclass
class AgentResult:
    """Uniform result envelope returned by every agent."""

    ok: bool
    data: object | None = None
    error: str = ""
    warnings: list[str] = field(default_factory=list)
    used_llm: bool = False


@dataclass
class ResumeAnalysis:
    """Bundle of everything the resume agent produces for the UI."""

    resume: ResumeData
    improvements: list[BulletImprovement] = field(default_factory=list)


class ResumeAgent:
    """Extracts structured resume data from a file or raw text."""

    name = "ResumeAgent"

    def __init__(self, llm: LLMService | None = None) -> None:
        self.llm = llm or LLMService()

    def run(self, *, file_path: Path | None = None, text: str | None = None) -> AgentResult:
        """Analyse a resume from a stored file or from raw text."""
        warnings: list[str] = []
        try:
            if file_path is not None:
                text = extract_text_from_file(Path(file_path))
            if not text or not text.strip():
                return AgentResult(
                    ok=False, error="No readable text was found in the resume."
                )
        except ValueError as exc:
            return AgentResult(ok=False, error=str(exc))
        except Exception as exc:  # noqa: BLE001
            logger.exception("Unexpected resume extraction failure")
            return AgentResult(
                ok=False, error=f"Could not read the resume ({type(exc).__name__})."
            )

        try:
            resume = parse_resume(text, llm=self.llm)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Resume parsing failed")
            return AgentResult(ok=False, error=f"Resume parsing failed: {exc}")

        if resume.is_empty():
            warnings.append(
                "Very little structured data was extracted. The resume may use an "
                "unusual layout - please review the text below and edit the fields."
            )

        return AgentResult(
            ok=True,
            data=resume,
            warnings=warnings,
            used_llm=self.llm.available,
        )

    def analyse(self, resume: ResumeData) -> ResumeAnalysis:
        """Combine parsing with bullet-point improvement suggestions."""
        return ResumeAnalysis(resume=resume, improvements=suggest_bullet_improvements(resume))


def suggest_bullet_improvements(
    resume: ResumeData, llm: LLMService | None = None
) -> list[BulletImprovement]:
    """Suggest clearer bullet points WITHOUT inventing metrics or facts.

    The deterministic engine rewrites weak phrasing (passive voice, vague verbs,
    missing structure) using only words already present in the original bullet.
    It never adds numbers, results or technologies that were not there.
    """
    weak_starts = {
        "worked on": "Developed",
        "helped": "Contributed to",
        "responsible for": "Owned",
        "was involved in": "Drove",
        "did": "Executed",
        "made": "Built",
        "used": "Applied",
    }
    improvements: list[BulletImprovement] = []
    sources = [("Experience", resume.experience), ("Projects", resume.projects)]

    for section, items in sources:
        for item in items:
            bullets: list[str] = []
            if section == "Experience":
                bullets = getattr(item, "description", []) or []
            else:
                desc = getattr(item, "description", "")
                bullets = [desc] if desc else []

            for bullet in bullets:
                if not bullet or len(bullet.strip()) < 15:
                    continue
                improved = bullet.strip()
                rationale_parts: list[str] = []
                for weak, strong in weak_starts.items():
                    if improved.lower().startswith(weak):
                        improved = strong + improved[len(weak):]
                        rationale_parts.append(f"replaced weak opener '{weak}'")
                if not improved[0].isupper():
                    improved = improved[0].upper() + improved[1:]
                    rationale_parts.append("capitalised the opening verb")

                if improved != bullet.strip():
                    improvements.append(
                        BulletImprovement(
                            section=section,
                            original=bullet.strip(),
                            improved=improved,
                            rationale="; ".join(rationale_parts)
                            or "tightened phrasing",
                            confidence="high" if rationale_parts else "medium",
                        )
                    )
    return improvements
