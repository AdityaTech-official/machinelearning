"""Job match agent: wraps the explainable scoring service as an agent."""

from __future__ import annotations

import logging

from agents.resume_agent import AgentResult
from database.models import JobRequirements, MatchResult, ResumeData
from services.llm_service import LLMService
from services.scoring_service import ScoringService

logger = logging.getLogger(__name__)


class JobMatchAgent:
    """Produces an explainable resume-to-job match result."""

    name = "JobMatchAgent"

    def __init__(
        self,
        llm: LLMService | None = None,
        scorer: ScoringService | None = None,
    ) -> None:
        self.llm = llm or LLMService()
        self.scorer = scorer or ScoringService()

    def run(self, resume: ResumeData, job: JobRequirements) -> AgentResult:
        """Validate inputs, then produce a :class:`MatchResult`."""
        if resume is None or resume.is_empty():
            return AgentResult(
                ok=False,
                error="A parsed resume is required before matching. Analyse the "
                "resume first.",
            )
        if job is None or job.is_empty():
            return AgentResult(
                ok=False, error="A parsed job description is required before matching."
            )

        try:
            if self.llm.available:
                result: MatchResult = self.scorer.match_with_llm(
                    resume, job, llm=self.llm
                )
            else:
                result = self.scorer.match(resume, job)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Matching failed; using deterministic engine")
            try:
                result = self.scorer.match(resume, job)
            except Exception as inner:  # noqa: BLE001
                return AgentResult(ok=False, error=f"Matching failed: {inner}")

        warnings: list[str] = []
        if result.unsupported:
            warnings.append(
                f"{len(result.unsupported)} requirement(s) could not be verified "
                "from a resume and were excluded from the score."
            )
        return AgentResult(
            ok=True,
            data=result,
            warnings=warnings,
            used_llm=self.llm.available,
        )
