"""Cover letter agent: generates an honest, resume-grounded draft."""

from __future__ import annotations

import logging

from agents.resume_agent import AgentResult
from database.models import JobRequirements, ResumeData
from services.llm_service import LLMService, load_prompt, render_prompt

logger = logging.getLogger(__name__)


class CoverLetterAgent:
    """Produces a personalised cover letter grounded strictly in real data."""

    name = "CoverLetterAgent"

    def __init__(self, llm: LLMService | None = None) -> None:
        self.llm = llm or LLMService()

    def run(self, resume: ResumeData, job: JobRequirements) -> AgentResult:
        """Return a plain-text cover letter draft."""
        if resume is None or resume.is_empty():
            return AgentResult(ok=False, error="A parsed resume is required.")

        if self.llm.available:
            try:
                letter = self._generate_with_llm(resume, job)
                if letter.strip():
                    return AgentResult(ok=True, data=letter, used_llm=True)
            except Exception as exc:  # noqa: BLE001
                logger.warning("LLM cover letter failed, using template: %s", exc)

        letter = self._template_letter(resume, job)
        return AgentResult(
            ok=True,
            data=letter,
            used_llm=False,
            warnings=[
                "Generated with the built-in deterministic template because no AI "
                "provider is configured. Review and personalise before sending."
            ],
        )

    # ------------------------------------------------------------------ #
    def _generate_with_llm(self, resume: ResumeData, job: JobRequirements) -> str:
        template = load_prompt("cover_letter_prompt.txt")
        projects = "; ".join(p.name for p in resume.projects[:3]) or "not listed"
        experience = "; ".join(
            f"{e.title}{' at ' + e.company if e.company else ''}"
            for e in resume.experience[:3]
        ) or "not listed"
        prompt = render_prompt(
            template,
            name=resume.name or "the candidate",
            email=resume.email,
            phone=resume.phone,
            skills=", ".join(resume.skills[:12]) or "not listed",
            projects=projects,
            experience=experience,
            company=job.company or "your organisation",
            role_title=job.title or "the advertised role",
            required_skills=", ".join(job.required_skills[:10]) or "not specified",
            responsibilities="; ".join(job.responsibilities[:4]) or "not specified",
        )
        return self.llm.complete(prompt, system="You are an expert career writer.")

    def _template_letter(self, resume: ResumeData, job: JobRequirements) -> str:
        """Deterministic, honest letter built only from facts in the resume."""
        company = job.company or "your organisation"
        role = job.title or "the advertised role"
        top_skills = ", ".join(resume.skills[:5]) or "a range of technical skills"
        project_line = ""
        if resume.projects:
            first = resume.projects[0]
            project_line = (
                f" I have applied these skills in projects such as "
                f"{first.name.strip()}, where I worked directly with the "
                f"technologies the role calls for."
            )
        experience_line = ""
        if resume.experience:
            exp = resume.experience[0]
            where = f" at {exp.company}" if exp.company else ""
            experience_line = (
                f" In my role as {exp.title}{where}, I built hands-on experience "
                f"that directly supports the responsibilities described."
            )

        return (
            f"Dear Hiring Manager,\n\n"
            f"I am writing to express my interest in the {role} position at "
            f"{company}. With a background in {top_skills}, I believe I can "
            f"contribute meaningfully to your team.{experience_line}{project_line}\n\n"
            f"Reviewing your requirements, I noticed the role emphasises "
            f"{', '.join(job.required_skills[:4]) or 'a strong technical foundation'}. "
            f"My resume demonstrates relevant work across these areas, and I am "
            f"eager to apply and extend these skills in your environment.\n\n"
            f"I would welcome the opportunity to discuss how my experience aligns "
            f"with your needs. Thank you for your time and consideration.\n\n"
            f"Sincerely,\n{resume.name or 'Candidate'}"
        )
