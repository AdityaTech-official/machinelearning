"""Orchestrator: coordinates the specialised agents and validates their output.

Responsibilities
----------------
* Route each task to the correct agent(s) with a single, predictable interface.
* Enforce ordering: resume -> job -> match -> (cover letter | skill gap).
* Validate every agent result and surface warnings/errors uniformly.
* Require explicit user confirmation before any *external* action.
* Never loop unnecessarily: each task calls the minimum number of agents.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from agents.cover_letter_agent import CoverLetterAgent
from agents.job_match_agent import JobMatchAgent
from agents.resume_agent import AgentResult, ResumeAgent, suggest_bullet_improvements
from agents.skill_gap_agent import SkillGapAgent
from database.models import (
    ApplicationRecord,
    BulletImprovement,
    JobRequirements,
    MatchResult,
    ResumeData,
    SkillGapPlan,
)
from database.repository import ApplicationRepository
from services.job_service import parse_job_description
from services.llm_service import LLMService

logger = logging.getLogger(__name__)


@dataclass
class PipelineResult:
    """Aggregated result of a full analysis run."""

    resume: Optional[ResumeData] = None
    job: Optional[JobRequirements] = None
    match: Optional[MatchResult] = None
    cover_letter: str = ""
    skill_gap: Optional[SkillGapPlan] = None
    improvements: list[BulletImprovement] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class Orchestrator:
    """Coordinates agents and services for the whole application."""

    def __init__(
        self,
        llm: LLMService | None = None,
        repository: ApplicationRepository | None = None,
    ) -> None:
        self.llm = llm or LLMService()
        self.repo = repository or ApplicationRepository()
        self.resume_agent = ResumeAgent(llm=self.llm)
        self.match_agent = JobMatchAgent(llm=self.llm)
        self.cover_agent = CoverLetterAgent(llm=self.llm)
        self.gap_agent = SkillGapAgent(llm=self.llm)

    # ------------------------------------------------------------------ #
    # Individual tasks
    # ------------------------------------------------------------------ #
    def analyse_resume(
        self, *, file_path: Path | None = None, text: str | None = None
    ) -> AgentResult:
        """Run the resume agent (parsing + improvement suggestions)."""
        result = self.resume_agent.run(file_path=file_path, text=text)
        if result.ok and isinstance(result.data, ResumeData):
            result.data = self._attach_improvements(result.data)
        return result

    def analyse_job(self, text: str) -> AgentResult:
        """Parse a pasted job description into structured requirements."""
        if not text or not text.strip():
            return AgentResult(ok=False, error="Please paste a job description first.")
        try:
            job = parse_job_description(text, llm=self.llm)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Job parsing failed")
            return AgentResult(ok=False, error=f"Could not parse the job description: {exc}")
        if job.is_empty():
            return AgentResult(
                ok=False,
                error="No recognisable requirements were found. Please paste the "
                "full job description text.",
            )
        return AgentResult(ok=True, data=job, used_llm=self.llm.available)

    def match(self, resume: ResumeData, job: JobRequirements) -> AgentResult:
        """Run the job-match agent."""
        return self.match_agent.run(resume, job)

    def cover_letter(self, resume: ResumeData, job: JobRequirements) -> AgentResult:
        """Run the cover-letter agent."""
        return self.cover_agent.run(resume, job)

    def skill_gap(
        self, resume: ResumeData, job: JobRequirements, match: MatchResult | None = None
    ) -> AgentResult:
        """Run the skill-gap agent."""
        return self.gap_agent.run(resume, job, match)

    # ------------------------------------------------------------------ #
    # Full pipeline
    # ------------------------------------------------------------------ #
    def run_full_pipeline(
        self,
        resume: ResumeData,
        job: JobRequirements,
        *,
        include_cover_letter: bool = True,
    ) -> PipelineResult:
        """Run resume -> match -> gaps -> (optional) cover letter in one pass.

        Ordered, bounded and warning-aggregating. It performs at most three
        agent calls (plus an optional fourth) and never loops.
        """
        outcome = PipelineResult(resume=resume, job=job)
        outcome.improvements = suggest_bullet_improvements(resume)

        match_res = self.match(resume, job)
        outcome.warnings.extend(match_res.warnings)
        if not match_res.ok:
            outcome.warnings.append(match_res.error)
            return outcome
        outcome.match = match_res.data  # type: ignore[assignment]

        gap_res = self.skill_gap(resume, job, outcome.match)
        outcome.warnings.extend(gap_res.warnings)
        if gap_res.ok:
            outcome.skill_gap = gap_res.data  # type: ignore[assignment]

        if include_cover_letter:
            letter_res = self.cover_letter(resume, job)
            outcome.warnings.extend(letter_res.warnings)
            if letter_res.ok:
                outcome.cover_letter = str(letter_res.data)
            else:
                outcome.warnings.append(letter_res.error)

        return outcome

    # ------------------------------------------------------------------ #
    # Tracker (requires explicit confirmation for the external-style action)
    # ------------------------------------------------------------------ #
    def save_application(
        self, record: ApplicationRecord, *, confirmed: bool
    ) -> tuple[bool, str]:
        """Persist an application record - but ONLY after user confirmation.

        This models the spec's rule that no external/persistent action happens
        without an explicit yes from the user.
        """
        if not confirmed:
            return False, "Confirmation required before saving this application."
        try:
            new_id = self.repo.create(record)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Failed to save application")
            return False, f"Could not save the application: {exc}"
        return True, f"Saved application #{new_id}."

    # ------------------------------------------------------------------ #
    def _attach_improvements(self, resume: ResumeData) -> ResumeData:
        """Attach improvement suggestions to the resume for the UI to render."""
        # Stored on the instance so the UI can access both without a second parse.
        self._last_improvements = suggest_bullet_improvements(resume)
        return resume

    @property
    def last_improvements(self) -> list[BulletImprovement]:
        """Improvements computed during the most recent resume analysis."""
        return getattr(self, "_last_improvements", [])

    # ------------------------------------------------------------------ #
    def external_action(self, action: str, confirmed: bool) -> tuple[bool, str]:
        """Gate ANY external action (send email, submit application) on consent.

        This application deliberately performs no automatic sending or
        submission; this method documents and enforces the confirmation rule.
        """
        if not confirmed:
            return False, (
                f"'{action}' requires explicit user confirmation. Tick the "
                "confirmation box to proceed."
            )
        return False, (
            f"'{action}' is intentionally not automated in this build. The app "
            "prepares everything for you to review and send manually - this "
            "prevents accidental submissions."
        )
