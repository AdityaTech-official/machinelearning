"""Tests for resume parsing: text extraction and structured parsing."""

from __future__ import annotations

from pathlib import Path

import pytest

from database.models import ResumeData
from services.resume_parser import (
    extract_text_from_file,
    parse_resume_deterministic,
)
from utils.validators import clean_text, extract_emails, extract_years_of_experience


class TestDeterministicParsing:
    """The offline rule engine must work without any API key."""

    def test_extracts_email_and_phone(self, sample_resume_text: str) -> None:
        result = parse_resume_deterministic(sample_resume_text)
        assert result.email == "priya.sharma@example.com"
        assert "9000000000" in result.phone

    def test_extracts_canonical_skills(self, sample_resume_text: str) -> None:
        result = parse_resume_deterministic(sample_resume_text)
        assert "Python" in result.skills
        assert "React" in result.skills
        assert "SQL" in result.skills

    def test_extracts_education(self, sample_resume_text: str) -> None:
        result = parse_resume_deterministic(sample_resume_text)
        assert result.education
        assert any("B.Tech" in e.degree for e in result.education)

    def test_extracts_projects_and_experience(self, sample_resume_text: str) -> None:
        result = parse_resume_deterministic(sample_resume_text)
        assert result.projects
        assert result.experience

    def test_empty_text_returns_empty_model(self) -> None:
        result = parse_resume_deterministic("")
        assert isinstance(result, ResumeData)
        assert result.is_empty()

    def test_skills_are_deduplicated(self) -> None:
        text = "SKILLS\nPython, Python, python, SQL"
        result = parse_resume_deterministic(text)
        assert result.skills.count("Python") == 1

    def test_does_not_invent_data(self) -> None:
        result = parse_resume_deterministic("Just some random words here.")
        assert result.experience == []
        assert result.education == []


class TestTextExtraction:
    """Extraction must fail safely on bad input."""

    def test_missing_file_raises_value_error(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="not found"):
            extract_text_from_file(tmp_path / "nope.pdf")

    def test_unsupported_extension_raises(self, tmp_path: Path) -> None:
        bad = tmp_path / "resume.xyz"
        bad.write_text("hello")
        with pytest.raises(ValueError, match="Unsupported file type"):
            extract_text_from_file(bad)

    def test_txt_extraction(self, tmp_path: Path) -> None:
        good = tmp_path / "resume.txt"
        good.write_text("Python developer with SQL experience.")
        assert "Python" in extract_text_from_file(good)

    def test_empty_txt_extraction(self, tmp_path: Path) -> None:
        empty = tmp_path / "empty.txt"
        empty.write_text("")
        assert extract_text_from_file(empty) == ""


class TestValidators:
    """Small helpers used across parsing."""

    def test_clean_text_normalises_whitespace(self) -> None:
        assert clean_text("a   b\n\n\n\nc") == "a b\n\nc"

    def test_extract_emails(self) -> None:
        assert extract_emails("reach me at a@b.com or c@d.org") == ["a@b.com", "c@d.org"]

    def test_extract_years(self) -> None:
        assert extract_years_of_experience("3+ years of experience") == 3.0
        assert extract_years_of_experience("no numbers here") == 0.0
