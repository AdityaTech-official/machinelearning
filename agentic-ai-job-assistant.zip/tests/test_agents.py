"""Tests for agents, the orchestrator and LLM output validation.

Every LLM call is mocked - these tests need no API key and no network.
"""

from __future__ import annotations

from agents.cover_letter_agent import CoverLetterAgent
from agents.job_match_agent import JobMatchAgent
from agents.orchestrator import Orchestrator
from agents.resume_agent import ResumeAgent, suggest_bullet_improvements
from agents.skill_gap_agent import SkillGapAgent
from database.models import (
    ApplicationRecord,
    JobRequirements,
    ResumeData,
)
from services.llm_service import LLMService, render_prompt


class TestResumeAgent:
    """Resume agent behaviour with and without an LLM."""

    def test_parses_from_text_without_llm(self, sample_resume_text: str) -> None:
        agent = ResumeAgent(llm=LLMService())  # no key in test env -> fallback
        result = agent.run(text=sample_resume_text)
        assert result.ok
        assert isinstance(result.data, ResumeData)
        assert result.data.skills

    def test_empty_text_fails_gracefully(self) -> None:
        result = ResumeAgent(llm=LLMService()).run(text="")
        assert not result.ok
        assert "No readable text" in result.error

    def test_missing_file_fails_gracefully(self, tmp_path) -> None:
        result = ResumeAgent(llm=LLMService()).run(file_path=tmp_path / "x.pdf")
        assert not result.ok
        assert result.error


class TestBulletImprovements:
    """Improvements must never invent metrics or facts."""

    def test_rewrites_weak_opener(self) -> None:
        resume = ResumeData(
            experience=[],
            projects=[],
        )
        from database.models import Experience

        resume.experience = [
            Experience(title="Intern", description=["worked on a data pipeline"])
        ]
        improvements = suggest_bullet_improvements(resume)
        assert improvements
        assert improvements[0].improved.startswith("Developed")
        # The original content survives - no new words invented.
        assert "data pipeline" in improvements[0].improved

    def test_does_not_add_numbers(self) -> None:
        from database.models import Experience

        resume = ResumeData(
            experience=[Experience(title="Intern", description=["helped the team ship features"])]
        )
        improvements = suggest_bullet_improvements(resume)
        assert improvements
        assert not any(char.isdigit() for char in improvements[0].improved)


class TestJobMatchAgent:
    """Matching agent validation of inputs."""

    def test_requires_resume(self, parsed_job) -> None:
        result = JobMatchAgent(llm=LLMService()).run(None, parsed_job)
        assert not result.ok

    def test_requires_job(self, parsed_resume) -> None:
        result = JobMatchAgent(llm=LLMService()).run(parsed_resume, None)
        assert not result.ok

    def test_produces_explainable_result(self, parsed_resume, parsed_job) -> None:
        result = JobMatchAgent(llm=LLMService()).run(parsed_resume, parsed_job)
        assert result.ok
        assert hasattr(result.data, "breakdown")
        assert result.data.disclaimer


class TestCoverLetterAgent:
    """Cover letters must only use supplied facts."""

    def test_template_letter_uses_real_name(self, parsed_resume, parsed_job) -> None:
        result = CoverLetterAgent(llm=LLMService()).run(parsed_resume, parsed_job)
        assert result.ok
        assert isinstance(result.data, str)
        assert len(result.data) > 100

    def test_no_llm_flag_set(self, parsed_resume, parsed_job) -> None:
        result = CoverLetterAgent(llm=LLMService()).run(parsed_resume, parsed_job)
        assert result.used_llm is False
        assert result.warnings


class TestSkillGapAgent:
    """Skill gap plans must separate required from preferred."""

    def test_builds_prioritised_plan(self, parsed_resume, parsed_job) -> None:
        match = JobMatchAgent(llm=LLMService()).run(parsed_resume, parsed_job).data
        result = SkillGapAgent(llm=LLMService()).run(parsed_resume, parsed_job, match)
        assert result.ok
        assert result.data.gaps
        priorities = [g.priority for g in result.data.gaps]
        assert priorities == sorted(priorities)

    def test_each_gap_has_why_and_steps(self, parsed_resume, parsed_job) -> None:
        result = SkillGapAgent(llm=LLMService()).run(parsed_resume, parsed_job)
        for gap in result.data.gaps:
            assert gap.why_it_matters
            assert gap.learning_steps
            assert gap.project_suggestion


class TestOrchestrator:
    """Orchestration, ordering and confirmation gating."""

    def test_full_pipeline_runs_end_to_end(
        self, parsed_resume, parsed_job, repository
    ) -> None:
        orchestrator = Orchestrator(llm=LLMService(), repository=repository)
        outcome = orchestrator.run_full_pipeline(parsed_resume, parsed_job)
        assert outcome.match is not None
        assert outcome.skill_gap is not None
        assert outcome.cover_letter

    def test_analyse_job_rejects_blank(self, repository) -> None:
        orch = Orchestrator(llm=LLMService(), repository=repository)
        result = orch.analyse_job("   ")
        assert not result.ok

    def test_save_requires_confirmation(self, repository) -> None:
        orch = Orchestrator(llm=LLMService(), repository=repository)
        record = ApplicationRecord(company="Acme", role="Intern")
        ok, message = orch.save_application(record, confirmed=False)
        assert not ok
        assert "Confirmation required" in message
        assert repository.total() == 0

    def test_save_with_confirmation_persists(self, repository) -> None:
        orch = Orchestrator(llm=LLMService(), repository=repository)
        record = ApplicationRecord(company="Acme", role="Intern", match_score=72.5)
        ok, message = orch.save_application(record, confirmed=True)
        assert ok
        assert repository.total() == 1
        assert repository.list_all()[0].company == "Acme"

    def test_external_action_gated_on_consent(self, repository) -> None:
        orch = Orchestrator(llm=LLMService(), repository=repository)
        ok, message = orch.external_action("Send email", confirmed=False)
        assert not ok
        assert "confirmation" in message.lower()


class TestLLMServiceValidation:
    """Structured output parsing and fallback behaviour, fully mocked."""

    def test_unavailable_without_key(self, monkeypatch) -> None:
        monkeypatch.setenv("OPENAI_API_KEY", "")
        service = LLMService()
        assert service.available is False

    def test_fallback_used_when_unavailable(self) -> None:
        service = LLMService()
        fallback = ResumeData(name="Fallback Person", skills=["Python"])
        result = service.complete_json("prompt", ResumeData, fallback=lambda: fallback)
        assert result.name == "Fallback Person"

    def test_valid_json_is_parsed(self) -> None:
        from tests.conftest import MockLLM

        payload = '{"name": "Test User", "skills": ["Python", "SQL"]}'
        service = LLMService(client=MockLLM(payload))
        result = service.complete_json("prompt", ResumeData)
        assert result.name == "Test User"
        assert result.skills == ["Python", "SQL"]

    def test_malformed_json_falls_back(self) -> None:
        from tests.conftest import MockLLM

        service = LLMService(client=MockLLM("this is not json"))
        fallback = ResumeData(name="Safe")
        result = service.complete_json("prompt", ResumeData, fallback=lambda: fallback)
        assert result.name == "Safe"

    def test_json_extraction_strips_markdown_fences(self) -> None:
        from tests.conftest import MockLLM

        fenced = '```json\n{"name": "Fenced", "skills": []}\n```'
        service = LLMService(client=MockLLM(fenced))
        assert service.complete_json("p", ResumeData).name == "Fenced"

    def test_render_prompt_tolerates_braces_in_data(self) -> None:
        out = render_prompt("A {x} B", x="json {nested} braces")
        assert "json {nested} braces" in out
