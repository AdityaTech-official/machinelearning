"""Tests for database operations, validation and file handling."""

from __future__ import annotations

from pathlib import Path

import pytest

from database.models import ApplicationRecord
from database.repository import ApplicationRepository
from utils.validators import (
    ValidationError,
    validate_extension,
    validate_size,
    validate_upload,
)


class TestDatabaseOperations:
    """CRUD, search and aggregates against a temporary database."""

    def test_create_and_get(self, repository: ApplicationRepository) -> None:
        new_id = repository.create(ApplicationRecord(company="Acme", role="SDE"))
        record = repository.get(new_id)
        assert record is not None
        assert record.company == "Acme"
        assert record.status == "Interested"

    def test_get_missing_returns_none(self, repository: ApplicationRepository) -> None:
        assert repository.get(9999) is None

    def test_update(self, repository: ApplicationRepository) -> None:
        new_id = repository.create(ApplicationRecord(company="Acme", role="SDE"))
        assert repository.update(new_id, status="Applied", notes="referred")
        updated = repository.get(new_id)
        assert updated.status == "Applied"
        assert updated.notes == "referred"

    def test_update_rejects_invalid_status(self, repository: ApplicationRepository) -> None:
        new_id = repository.create(ApplicationRecord(company="Acme", role="SDE"))
        with pytest.raises(ValueError):
            repository.update(new_id, status="Ghosted")

    def test_delete(self, repository: ApplicationRepository) -> None:
        new_id = repository.create(ApplicationRecord(company="Acme", role="SDE"))
        assert repository.delete(new_id) is True
        assert repository.get(new_id) is None
        assert repository.delete(new_id) is False

    def test_search_matches_role_and_company(self, repository: ApplicationRepository) -> None:
        repository.create(ApplicationRecord(company="Acme", role="Backend Engineer"))
        repository.create(ApplicationRecord(company="Globex", role="Data Analyst"))
        assert len(repository.search("acme")) == 1
        assert len(repository.search("analyst")) == 1
        assert len(repository.search("zzz")) == 0

    def test_count_by_status_includes_zeroes(self, repository: ApplicationRepository) -> None:
        repository.create(ApplicationRecord(company="Acme", role="SDE", status="Applied"))
        counts = repository.count_by_status()
        assert counts["Applied"] == 1
        assert counts["Offer"] == 0

    def test_average_match_score(self, repository: ApplicationRepository) -> None:
        repository.create(ApplicationRecord(company="A", role="x", match_score=80.0))
        repository.create(ApplicationRecord(company="B", role="y", match_score=60.0))
        assert repository.average_match_score() == 70.0

    def test_recent_returns_limit(self, repository: ApplicationRepository) -> None:
        for i in range(7):
            repository.create(ApplicationRecord(company=f"C{i}", role="r"))
        assert len(repository.recent(limit=3)) == 3

    def test_total_and_empty_average(self, repository: ApplicationRepository) -> None:
        assert repository.total() == 0
        assert repository.average_match_score() == 0.0


class TestApplicationRecordValidation:
    """The Pydantic model must reject bad data."""

    def test_invalid_status_rejected(self) -> None:
        with pytest.raises(ValueError):
            ApplicationRecord(company="A", role="r", status="Nonsense")

    def test_blank_company_rejected(self) -> None:
        with pytest.raises(ValueError):
            ApplicationRecord(company="   ", role="r")

    def test_defaults(self) -> None:
        record = ApplicationRecord(company="Acme", role="SDE")
        assert record.status == "Interested"
        assert record.match_score is None


class TestUploadValidation:
    """Upload guards against invalid, empty and oversized files."""

    def test_valid_extension(self) -> None:
        assert validate_extension("resume.pdf") == ".pdf"
        assert validate_extension("CV.DOCX") == ".docx"

    def test_invalid_extension(self) -> None:
        with pytest.raises(ValidationError):
            validate_extension("resume.exe")

    def test_no_extension(self) -> None:
        with pytest.raises(ValidationError, match="no extension"):
            validate_extension("resume")

    def test_empty_file_rejected(self) -> None:
        with pytest.raises(ValidationError, match="empty"):
            validate_size(0)

    def test_oversized_file_rejected(self) -> None:
        with pytest.raises(ValidationError, match="exceeds"):
            validate_size(50 * 1024 * 1024)

    def test_validate_upload_ok(self) -> None:
        assert validate_upload("resume.pdf", 1024) == ".pdf"


class TestFileHandler:
    """Saving uploads must sanitise names and refuse bad files."""

    def test_sanitise_filename(self) -> None:
        from utils.file_handler import sanitise_filename

        assert sanitise_filename("../../etc/passwd") == "passwd"
        assert "/" not in sanitise_filename("a/b/c.pdf")

    def test_save_upload_rejects_bad_extension(self, tmp_path: Path) -> None:
        from utils.file_handler import FileHandlingError, save_upload

        class FakeUpload:
            name = "evil.exe"

            def getvalue(self) -> bytes:
                return b"data"

        with pytest.raises((ValidationError, FileHandlingError)):
            save_upload(FakeUpload(), upload_dir=tmp_path)

    def test_save_upload_writes_file(self, tmp_path: Path) -> None:
        from utils.file_handler import save_upload

        class FakeUpload:
            name = "resume.pdf"

            def getvalue(self) -> bytes:
                return b"%PDF-1.4 fake"

        path = save_upload(FakeUpload(), upload_dir=tmp_path)
        assert path.exists()
        assert path.read_bytes().startswith(b"%PDF")
