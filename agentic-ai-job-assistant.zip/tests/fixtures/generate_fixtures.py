#!/usr/bin/env python3
"""Generate synthetic resume fixtures (PDF + DOCX) and sample job descriptions.

Everything here is fictional. No real person's data is used.

Run:
    python tests/fixtures/generate_fixtures.py
"""

from __future__ import annotations

from pathlib import Path

FIXTURES = Path(__file__).resolve().parent

RESUME_TEXT = """PRIYA SHARMA
priya.sharma@example.com | +91-9000000000

SUMMARY
Final-year Computer Science student with hands-on experience in Python, web
development and data analysis.

EDUCATION
B.Tech in Computer Science, Example Institute of Technology, 2025

SKILLS
Python, SQL, JavaScript, React, Node.js, Git, Data Structures, Algorithms,
Pandas, NumPy, Docker

EXPERIENCE
Software Engineering Intern, Acme Analytics, 2024
Worked on a Python data pipeline to clean and aggregate daily metrics.
Helped build a React dashboard used by the operations team.

PROJECTS
Student Result Portal
Built a Flask web app with SQLite for managing student results.
Task Tracker
Developed a React and Node.js task tracking application.

CERTIFICATIONS
AWS Cloud Practitioner, Amazon, 2024
"""

JOB_TEXT = """Junior Data Engineer
Example Corp

About the role
You will build and maintain data pipelines for the analytics team and support
the delivery of data models.

Requirements
- Must have strong Python programming skills
- Required experience with SQL and relational databases
- 2 years of software development experience
- Bachelor degree in Computer Science or related field

Preferred
- Experience with AWS and Docker
- Familiarity with Kubernetes is a nice to have
- Exposure to Machine Learning

Responsibilities
- Build ETL pipelines using Python
- Collaborate with analysts to deliver clean data models
- Write tests and documentation for the pipelines
"""


def write_text_files() -> None:
    (FIXTURES / "sample_resume.txt").write_text(RESUME_TEXT, encoding="utf-8")
    (FIXTURES / "sample_job.txt").write_text(JOB_TEXT, encoding="utf-8")
    print("Wrote sample_resume.txt and sample_job.txt")


def write_docx() -> None:
    try:
        import docx
    except ImportError:
        print("python-docx not installed; skipping DOCX fixture")
        return

    document = docx.Document()
    for block in RESUME_TEXT.split("\n"):
        if block.isupper() and block.strip():
            document.add_heading(block.strip(), level=2)
        elif block.startswith("- "):
            document.add_paragraph(block[2:], style="List Bullet")
        elif block.strip():
            document.add_paragraph(block.strip())
    document.save(FIXTURES / "sample_resume.docx")
    print("Wrote sample_resume.docx")


def write_pdf() -> None:
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
    except ImportError:
        print("reportlab not installed; skipping PDF fixture")
        return

    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(FIXTURES / "sample_resume.pdf"), pagesize=A4)
    story = []
    for block in RESUME_TEXT.split("\n"):
        if not block.strip():
            story.append(Spacer(1, 6))
            continue
        style = styles["Heading3"] if block.isupper() else styles["BodyText"]
        story.append(Paragraph(block.strip(), style))
    doc.build(story)
    print("Wrote sample_resume.pdf")


if __name__ == "__main__":
    write_text_files()
    write_docx()
    write_pdf()
    print(f"Fixtures written to {FIXTURES}")
