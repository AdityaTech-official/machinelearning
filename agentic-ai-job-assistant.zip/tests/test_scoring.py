"""Tests for the explainable scoring engine."""

from __future__ import annotations

import pytest

from config.settings import ScoringWeights
from database.models import (
    Education,
    JobRequirements,
    ResumeData,
    SkillMatch,
)
from services.scoring_service import ScoringService


class TestScoreComputation:
    """The score must be deterministic, transparent and bounded."""

    def test_perfect_overlap_scores_high(self, parsed_resume, parsed_job) -> None:
        scorer = ScoringService()
        result = scorer.match(parsed_resume, parsed_job)
        assert 0.0 <= result.overall_score <= 100.0
        assert result.matched, "expected at least one matched skill"

    def test_no_skills_scores_low(self) -> None:
        resume = ResumeData(skills=[], raw_text="nothing relevant")
        job = JobRequirements(required_skills=["Rust", "Kubernetes", "Go"])
        result = ScoringService().match(resume, job)
        assert result.overall_score < 50
        assert not result.matched
        assert result.missing

    def test_breakdown_is_complete(self, parsed_resume, parsed_job) -> None:
        result = ScoringService().match(parsed_resume, parsed_job)
        expected_keys = {
            "Required skills",
            "Preferred skills",
            "Experience",
            "Education",
            "Resume completeness",
        }
        assert expected_keys == set(result.breakdown)
        assert all(0 <= v <= 100 for v in result.breakdown.values())

    def test_exact_skill_is_matched(self) -> None:
        resume = ResumeData(skills=["Python"], raw_text="Python")
        job = JobRequirements(required_skills=["Python"])
        result = ScoringService().match(resume, job)
        assert [m.skill for m in result.matched] == ["Python"]

    def test_related_skill_is_partial(self) -> None:
        resume = ResumeData(skills=["JavaScript"], raw_text="JavaScript")
        job = JobRequirements(required_skills=["React"])
        result = ScoringService().match(resume, job)
        assert [m.skill for m in result.partial] == ["React"]
        assert "Related skill present" in result.partial[0].evidence

    def test_unverifiable_requirement_is_unsupported(self) -> None:
        resume = ResumeData(skills=["Python"], raw_text="Python")
        job = JobRequirements(qualifications=["Must be authorized to work in the US"])
        result = ScoringService().match(resume, job)
        assert result.unsupported
        assert "authorized to work" in result.unsupported[0].skill.lower()

    def test_disclaimer_is_always_present(self, parsed_resume, parsed_job) -> None:
        result = ScoringService().match(parsed_resume, parsed_job)
        assert "NOT a prediction of hiring probability" in result.disclaimer

    def test_weights_change_the_score(self) -> None:
        resume = ResumeData(
            skills=["Python", "SQL"], raw_text="Python SQL",
            education=[Education(degree="B.Tech")],
        )
        job = JobRequirements(required_skills=["Python", "SQL", "Docker"])
        default = ScoringService().match(resume, job).overall_score
        required_heavy = ScoringService(
            weights=ScoringWeights(required_skills=0.9, preferred_skills=0.0,
                                   experience=0.05, education=0.025,
                                   resume_completeness=0.025)
        ).match(resume, job).overall_score
        assert default != required_heavy

    def test_score_bounds_with_empty_job(self, parsed_resume) -> None:
        result = ScoringService().match(parsed_resume, JobRequirements())
        assert 0.0 <= result.overall_score <= 100.0

    def test_no_invented_skills_in_output(self) -> None:
        resume = ResumeData(skills=["Python"], raw_text="Python only")
        job = JobRequirements(required_skills=["Python", "Terraform"])
        result = ScoringService().match(resume, job)
        all_skills = {m.skill for m in result.matched + result.missing + result.partial}
        assert all_skills <= {"Python", "Terraform"}


class TestSkillMatchModel:
    """Sanity checks on the Pydantic container types."""

    def test_skill_match_requires_skill(self) -> None:
        with pytest.raises(Exception):
            SkillMatch()
