"""Shared pytest fixtures.

All fixtures are offline: no network, no API key, no real personal data.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Ensure the project root is importable when pytest is run from anywhere.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from database.models import JobRequirements, ResumeData  # noqa: E402
from database.repository import ApplicationRepository  # noqa: E402


@pytest.fixture()
def sample_resume_text() -> str:
    """A synthetic resume - entirely fictional, no real person's data."""
    return """PRIYA SHARMA
priya.sharma@example.com | +91-9000000000

SUMMARY
Final-year Computer Science student with hands-on experience in Python and web development.

EDUCATION
B.Tech in Computer Science, Example Institute of Technology, 2025

SKILLS
Python, SQL, JavaScript, React, Git, Data Structures, Algorithms, Pandas

EXPERIENCE
Software Engineering Intern, Acme Analytics, 2024
Worked on a Python data pipeline to clean and aggregate daily metrics.
Helped build a React dashboard used by the operations team.

PROJECTS
Student Result Portal
Built a Flask web app with SQLite for managing student results.
Task Tracker
Developed a React and Node.js task tracking application.

CERTIFICATIONS
AWS Cloud Practitioner, Amazon, 2024
"""


@pytest.fixture()
def sample_job_text() -> str:
    """A synthetic job description - fictional company and role."""
    return """Junior Data Engineer
Example Corp

About the role
You will build and maintain data pipelines for the analytics team.

Requirements
- Must have strong Python programming skills
- Required experience with SQL and relational databases
- 2 years of software development experience
- Bachelor degree in Computer Science or related field

Preferred
- Experience with AWS and Docker
- Familiarity with Kubernetes is a nice to have
- Exposure to Machine Learning

Responsibilities
- Build ETL pipelines using Python
- Collaborate with analysts to deliver data models
"""


@pytest.fixture()
def parsed_resume(sample_resume_text: str) -> ResumeData:
    """Deterministically parsed sample resume."""
    from services.resume_parser import parse_resume_deterministic

    return parse_resume_deterministic(sample_resume_text)


@pytest.fixture()
def parsed_job(sample_job_text: str) -> JobRequirements:
    """Deterministically parsed sample job description."""
    from services.job_service import parse_job_deterministic

    return parse_job_deterministic(sample_job_text)


@pytest.fixture()
def repository(tmp_path: Path) -> ApplicationRepository:
    """A repository backed by a throwaway SQLite file."""
    return ApplicationRepository(db_path=tmp_path / "test.db")


class MockLLM:
    """A fake LLM client that returns canned content without any network call."""

    def __init__(self, response: str = "Mocked response") -> None:
        self.response = response

    def invoke(self, messages):  # noqa: ANN001 - mirrors LangChain's interface
        """Return a canned object exposing ``.content``."""

        class _Response:
            content = self.response

        return _Response()


@pytest.fixture()
def mock_llm_client() -> MockLLM:
    """A mock chat client that can be injected into LLMService."""
    return MockLLM()
